//
//  AppException.java
//  TransactionBeans
//
//  Created by Stefan Reich on Tue Nov 27 2001.
//  Copyright (c) 2001 __MyCompanyName__. All rights reserved.
//

package transactiontests;

public class AppException extends java.lang.Exception {

}
