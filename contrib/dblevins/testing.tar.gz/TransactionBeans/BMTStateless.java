package transactiontests;

import javax.ejb.*;
import java.rmi.RemoteException;
import java.rmi.Remote;

public interface BMTStateless extends EJBObject, BMTMethods {

    //
    // Business Logic Interfaces
    //

}