package ejb;

import java.rmi.*;
import javax.ejb.*;
import javax.naming.*;
/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class HelloClient {

  public HelloClient() {
  }

  public static void main(String[] args){
    try{
      //java.util.Properties env = new java.util.Properties();
      //env.setProperty(Context.INITIAL_CONTEXT_FACTORY,"org.openorb.rmi.jndi.CtxFactory");
      java.util.Hashtable env = new java.util.Hashtable();
      env.put(Context.INITIAL_CONTEXT_FACTORY,"org.openorb.rmi.jndi.CtxFactory");
      //env.put("InitialNamingContext","corbaloc:iiop:1.2@172.16.161.141:2001/NameService");
      /*
      env.setProperty("InitialNamingContext","corbaloc:iiop:1.2@localhost:2001/NameService");
      env.setProperty("org.omg.CORBA.ORBClass","org.openorb.CORBA.ORB");
      env.setProperty("org.omg.CORBA.ORBSingletonClass","org.openorb.CORBA.ORBSingleton");
      env.setProperty("javax.rmi.CORBA.StubClass","org.openorb.rmi.system.StubDelegateImpl");
      env.setProperty("javax.rmi.CORBA.UtilClass","org.openorb.rmi.system.UtilDelegateImpl");
      env.setProperty("javax.rmi.CORBA.PortableRemoteObjectClass","org.openorb.rmi.system.PortableRemoteObjectDelegateImpl");
      */
      Context context = new InitialContext(env);
      java.lang.Object obj =context.lookup("Hello");
      
      //System.out.println(context.lookup(""));
      
      HelloHome home = (HelloHome)javax.rmi.PortableRemoteObject.narrow(obj,HelloHome.class);
      Hello hello = home.create();
      System.out.println(hello.sayHello());
    }catch(Exception err){
      err.printStackTrace();
    }
  }
}