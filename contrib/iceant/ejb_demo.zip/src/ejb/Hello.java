package ejb;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

public interface Hello extends EJBObject {
  public String sayHello() throws RemoteException;
}