package ejb;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

public interface HelloHome extends EJBHome {
  public Hello create() throws RemoteException, CreateException;
}