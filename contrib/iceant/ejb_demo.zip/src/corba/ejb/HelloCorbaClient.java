package ejb;

public class HelloCorbaClient {
    public static void main( String [] args )
    {
        System.out.println("Hello client for CORBA...");

        org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init( args, null );

        org.omg.CosNaming.NamingContext naming = null;
        try {
            org.omg.CORBA.Object obj = orb.resolve_initial_references("NameService");

            naming = org.omg.CosNaming.NamingContextHelper.narrow( obj );
        } catch ( org.omg.CORBA.ORBPackage.InvalidName ex ) {
        }

        try {
            org.omg.CosNaming.NameComponent [] name = new org.omg.CosNaming.NameComponent[ 1 ];
            name[0] = new org.omg.CosNaming.NameComponent("client/ejb/Hello","");

            org.omg.CORBA.Object obj = naming.resolve( name );

            ejb.HelloHome rmi = ejb.RemoteHelloHelper.narrow( obj );

            rmi.print("Hello from a CORBA client...");
        } catch ( java.lang.Exception ex ) {
            System.out.println("Exception : " + ex.toString() );
            System.exit(0);
        }
    }
}
