package com.nrfx.articles.openejb;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Vector;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.EntityBean;
import javax.ejb.EntityContext;
import javax.ejb.FinderException;
import javax.ejb.NoSuchEntityException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * The bean class for the Employee EJB
 * <br>
 *
 * This Employee represents a record in the EMPLOYEE table.
 * It has the following persistent attributes:
 *
 * <pre>
 * ATTRIBUTE                DB FIELD
 * -----------------------  ------------------
 * firstName                first_name
 * lastName                 last_name
 * salary                   salary
 * dateHired                date_hired
 * </pre>
 *
 * Instances of this class are created and controlled
 * by the EJB Container.  This object should never be
 * instantiated via a 'new EmployeeBean' call.
 * <br>
 *
 * @see Employee
 * @see EmployeeHome
 */
public class EmployeeBean implements EntityBean {

    private static final Object[] NO_PARAMS = new Object[0];

    private EntityContext entityContext;
    private Context envContext;
    private DataSource dataSource;
    private Connection connection;

    private boolean loaded;

    /**
     * This is static and final because we only want one
     * SQL cache per bean type.
     */
    private static final HashMap sqlMap = new HashMap();

    /**
     * The firstName for this Employee.
     * Maps to the first_name field in the database.
     */
    private String firstName;
    /**
     * The lastName for this Employee.
     * Maps to the last_name field in the database.
     */
    private String lastName;
    /**
     * The salary for this Employee.
     * Maps to the salary field in the database.
     */
    private int salary;
    /**
     * The dateHired for this Employee.
     * Maps to the date_hired field in the database.
     */
    private Date dateHired;

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        if ( equals(this.firstName, firstName) ) return;

        try {
            getWrappedStatement("setFirstName").executeUpdate(firstName,getPrimaryKey());
            this.firstName = firstName;
        } catch (Exception e) {
            throw new EJBException("Unable to update the FirstName field to '"
                    + firstName +"' for this Employee ("
                    + getPrimaryKey() +"). ", e);
        }
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        if ( equals(this.lastName, lastName) ) return;

        try {
            getWrappedStatement("setLastName").executeUpdate(lastName,getPrimaryKey());
            this.lastName = lastName;
        } catch (Exception e) {
            throw new EJBException("Unable to update the LastName field to '"
                    + lastName +"' for this Employee ("
                    + getPrimaryKey() +"). ", e);
        }
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        if (this.salary == salary) return;

        try {
            getWrappedStatement("setSalary").executeUpdate(new Integer(salary),getPrimaryKey());
            this.salary = salary;
        } catch (Exception e) {
            throw new EJBException("Unable to update the Salary field to '"
                    + salary +"' for this Employee ("
                    + getPrimaryKey() +"). ", e);
        }
    }

    public Date getDateHired() {
        return dateHired;
    }

    public void setDateHired(Date dateHired) {
        if ( equals(this.dateHired, dateHired) ) return;

        try {
            getWrappedStatement("setDateHired").executeUpdate(dateHired,getPrimaryKey());
            this.dateHired = dateHired;
        } catch (Exception e) {
            throw new EJBException("Unable to update the DateHired field to '"
                    + dateHired +"' for this Employee ("
                    + getPrimaryKey() +"). ", e);
        }
    }

    public Integer ejbCreate(String firstName, String lastName, int salary, Date dateHired) throws CreateException {
        Integer key = null;
        try {
            key = findSingle("getPrimaryKey",NO_PARAMS);
            Object[] newData = new Object[]{ key, firstName, lastName, new Integer(salary), dateHired };
            getWrappedStatement("createEmployee").executeUpdate(newData);
        } catch (Exception e){
            throw new CreateException("Could not create the Employee. "+
                    e.getMessage());
        } finally {
            closeConnection();
        }
        return key;
    }

    public void ejbPostCreate(String firstName, String lastName, int salary, Date dateHired) {
    }

    public Integer ejbCreate(String firstName, String lastName) throws CreateException {
        return ejbCreate(firstName, lastName, 0, new Date(System.currentTimeMillis()));
    }
    public void ejbPostCreate(String firstName, String lastName) {
    }

    public Collection ejbFindByFirstName(String firstName) throws FinderException {
        return findMultiple("findByFirstName",new Object[]{firstName});
    }

    public Collection ejbFindByLastName(String lastName) throws FinderException {
        return findMultiple("findByLastName",new Object[]{lastName});
    }

    public Collection ejbFindBySalary(int salary) throws FinderException {
        return findMultiple("findBySalary",new Object[]{new Integer(salary)});
    }

    public Integer ejbFindByPrimaryKey(Integer key) throws FinderException {
        return findSingle("findByPrimaryKey",new Object[]{key});
    }

    public Collection ejbFindAllEmployees() throws FinderException {
        return findMultiple("findAllEmployees",NO_PARAMS);
    }

    public void ejbLoad() {
        // Don't load if we already have data
        if ( loaded ) return;


        try {
            Integer key = (Integer) entityContext.getPrimaryKey();
            Object[] params = new Object[]{key};
            PreparedStatement preparedStatement = null;
            for (int i=0; i < params.length; i++) {
                preparedStatement = getPreparedStatement("loadEmployee");
                new PreparedStatementWrapper(preparedStatement).set(i+1,params[i]);
            }

            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
                firstName = rs.getString("first_name");
                lastName = rs.getString("last_name");
                salary = rs.getInt("salary");
                dateHired = rs.getDate("date_hired");
            }

            loaded = true;

        } catch (Exception e) {
            throw new EJBException("Error while loading the Employee ("
                    +entityContext.getPrimaryKey()+"). "+e.getMessage(),e);
        } finally {
            closeConnection();
        }


    }

    // -------------------------------------------- //
    // EntityBean interface methods                 //
    // -------------------------------------------- //

    public void setEntityContext(EntityContext ctx) {
        this.entityContext = ctx;
        try {
            envContext = (Context)new InitialContext().lookup("java:comp/env");
            dataSource = (DataSource)envContext.lookup("jdbc/exampledatabase");
        } catch (NamingException e) {
            throw new RuntimeException(e);
        }
    }

    public void unsetEntityContext() {
    }

    public void ejbPassivate() {
        cleanState();
    }

    public void ejbActivate() {
        cleanState();
    }

    public void ejbRemove() {
        closeConnection();
    }

    public void ejbStore() {
        closeConnection();
    }



    /// ------------------------------------------ //
    /// Very boring convenience methods            //
    /// ------------------------------------------ //

    protected void cleanState() {
        this.loaded = false;
        this.firstName = null;
        this.lastName = null;
        this.salary = 0;
        this.dateHired = null;
    }
    public Integer findSingle(String sqlName, Object[] params) throws FinderException {
        Integer key = null;

        try {
            ResultSet rs = getWrappedStatement(sqlName).executeQuery(params);
            while (rs.next()) {
                key = new Integer(rs.getInt(1));
            }
        } catch (Exception e) {
            throw new EJBException("Unable to get the entity's primary key.",e);
        } finally {
            closeConnection();
        }

        if (key == null) {
            throw new NoSuchEntityException("No objects found.");
        }

        return key;
    }

    public Collection findMultiple(String sqlName, Object[] params) throws FinderException {
        Vector keys = new Vector();

        try {
            ResultSet rs = getWrappedStatement(sqlName).executeQuery(params);
            while (rs.next()) {
                keys.add( new Integer(rs.getInt(1)) );
            }
        } catch (Exception e) {
            throw new EJBException("Unable to get the entity's primary key.",e);
        } finally {
            closeConnection();
        }

        if (keys.size() < 1) {
            throw new NoSuchEntityException("No objects found.");
        }

        return keys;
    }
    public boolean equals (Object obj1, Object obj2){
        return (obj1 != null) ? obj1.equals(obj2) : obj2 == null;
    }
    private PreparedStatementWrapper getWrappedStatement(String sqlName) throws SQLException {
        return new PreparedStatementWrapper(getPreparedStatement(sqlName));
    }
    private PreparedStatement getPreparedStatement(String sqlName) throws SQLException {
        String sql = null;
        if (connection == null) {
            connection = dataSource.getConnection();
        }
        try {
            sql = (String)sqlMap.get(sqlName);
            if (sql == null) {
                sql = (String)envContext.lookup("sql/"+sqlName);
                sqlMap.put(sqlName, sql);
            }
        } catch (Exception e) {
            throw new SQLException("Error while retrieving SQL. "+e.getMessage());
        }
        return connection.prepareStatement(sql);
    }

    private Integer getPrimaryKey() {
        Integer key = null;
        try {
            key = (Integer) entityContext.getPrimaryKey();
        } catch (Exception e) {
            throw new EJBException("Unable to get this object's primary key.",e);
        }
        return key;
    }

    protected void closeConnection() {
        try {
            if (connection != null) {
                connection.close();
                connection = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}