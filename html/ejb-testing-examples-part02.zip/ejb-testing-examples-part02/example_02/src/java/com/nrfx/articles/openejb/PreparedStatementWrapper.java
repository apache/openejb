package com.nrfx.articles.openejb;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;
import java.sql.SQLException;

/**
 * @author David Blevins <david.blevins@visi.com>
 */
public class PreparedStatementWrapper {

    protected static final Object[] NO_PARAMS = new Object[0];

    private PreparedStatement statement;

    public PreparedStatementWrapper(PreparedStatement statement) {
        this.statement = statement;
    }

    public PreparedStatement getPreparedStatement() {
        return statement;
    }

    public void set(int i, Object obj) throws SQLException{
        if (obj == null) setNull(i);
        else if (obj instanceof String) set(i,(String)obj);
        else if (obj instanceof Integer) set(i,(Integer)obj);
        else if (obj instanceof Boolean) set(i,(Boolean)obj);
        else if (obj instanceof Byte) set(i,(Byte)obj);
        else if (obj instanceof Short) set(i,(Short)obj);
        else if (obj instanceof Long) set(i,(Long)obj);
        else if (obj instanceof Float) set(i,(Float)obj);
        else if (obj instanceof Double) set(i,(Double)obj);
        else if (obj instanceof Date) set(i,(Date)obj);
        else statement.setObject(1,obj);
    }

    public void setNull(int i) throws SQLException {
        statement.setNull(i,java.sql.Types.NULL);
    }

    public void set(int i, String data) throws SQLException {
        statement.setString(i, data);
    }

    public void set(int i, Integer data) throws SQLException {
        statement.setInt(i, data.intValue());
    }

    public void set(int i, Boolean data) throws SQLException {
        statement.setBoolean(i, data.booleanValue());
    }

    public void set(int i, Byte data) throws SQLException {
        statement.setByte(i, data.byteValue());
    }

    public void set(int i, Short data) throws SQLException {
        statement.setShort(i, data.shortValue());
    }

    public void set(int i, Long data) throws SQLException {
        statement.setLong(i, data.longValue());
    }

    public void set(int i, Float data) throws SQLException {
        statement.setFloat(i, data.floatValue());
    }

    public void set(int i, Double data) throws SQLException {
        statement.setDouble(i, data.doubleValue());
    }

    public void set(int i, Date data) throws SQLException {
        statement.setDate(i, data);
    }

    /**
     * It takes an sqlName string and a list of parameters.
     *
     * The sqlName string is used to lookup an actual SQL string from JNDI.
     * A PreparedStatement is created from the SQL string and the params
     * passed in are used to populate the statement.
     *
     * @param sqlName The name of a SQL string in
     *                the java:comp/env/sql JNDI context
     * @param params  The parameters to be used in the PreparedStatement
     *
     * @return Returns the ResultSet from executing the PreparedStatement
     * @exception FinderException if no entities are found
     */
    public ResultSet executeQuery(Object[] params) throws SQLException{
        for (int i=0; i < params.length; i++) {
            set(i+1,params[i]);
        }
        return statement.executeQuery();
    }

    public ResultSet executeQuery() throws SQLException {
        return executeQuery(NO_PARAMS);
    }
    public ResultSet executeQuery(Object p1) throws SQLException {
        return executeQuery(new Object[]{p1});
    }
    public ResultSet executeQuery(Object p1, Object p2) throws SQLException {
        return executeQuery(new Object[]{p1,p2});
    }
    public ResultSet executeQuery(Object p1, Object p2, Object p3) throws SQLException {
        return executeQuery(new Object[]{p1,p2,p3});
    }
    public ResultSet executeQuery(Object p1, Object p2, Object p3, Object p4) throws SQLException {
        return executeQuery(new Object[]{p1,p2,p3,p4});
    }


    /**
     * It takes an sqlName string and a list of parameters.
     *
     * The sqlName string is used to lookup an actual SQL string from JNDI.
     * A PreparedStatement is created from the SQL string and the params
     * passed in are used to populate the statement.
     *
     * @param sqlName The name of a SQL string in
     *                the java:comp/env/sql JNDI context
     * @param params  The parameters to be used in the PreparedStatement
     *
     * @return Returns the ResultSet from executing the PreparedStatement
     * @exception FinderException if no entities are found
     */
    public int executeUpdate(Object[] params) throws SQLException{
        for (int i=0; i < params.length; i++) {
            set(i+1,params[i]);
        }

        return statement.executeUpdate();
    }

    public int executeUpdate() throws SQLException {
        return executeUpdate(NO_PARAMS);
    }

    public int executeUpdate(Object p1) throws SQLException {
        return executeUpdate(new Object[]{p1});
    }

    public int executeUpdate(Object p1, Object p2) throws SQLException {
        return executeUpdate(new Object[]{p1,p2});
    }

    public int executeUpdate(Object p1, Object p2, Object p3) throws SQLException {
        return executeUpdate(new Object[]{p1,p2,p3});
    }

    public int executeUpdate(Object p1, Object p2, Object p3, Object p4) throws SQLException {
        return executeUpdate(new Object[]{p1,p2,p3,p4});
    }
}