package com.nrfx.articles.openejb;

import java.util.Collection;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;
import javax.ejb.FinderException;
import java.rmi.RemoteException;
import java.sql.Date;

/**
 * Home interface for the Employee EJB
 * <br>
 * This object can be used to construct or locate Employee objects.
 * <br>
 * Callng a create method on this object inserts an new record
 * in the EMPLOYEE table and returns a Employee object to represent that
 * new record.
 * <br>
 * Calling a find method on this object selects the matching records
 * from the EMPLOYEE table and returns a Employee object for each record.
 * <br>
 * Find methods that can select more than one record will return
 * a java.util.Collection of objects that are of type Employee.
 * To put the objects from the Collection into an array, code
 * like the following can be used:
 *
 * <pre>
 *  Collection objects = employeeHome.getAllEmployees();
 *
 *  Employee[] employees = new Employee[objects.size()];
 *  objects.toArray(employees);
 *  ...
 * </pre>
 *
 * @see Employee
 * @see EmployeeBean
 */
public interface EmployeeHome extends EJBHome {

    /**
     * Creates a new Employee in the database and returns
     * an object to represent it.
     *
     * @param firstName
     * @param lastName
     * @param salary
     * @param dateHired
     * @return A Employee object that represents the new record
     */
    public Employee create(String firstName, String lastName, int salary, Date dateHired) throws CreateException, RemoteException;

    /**
     * Creates a new Employee in the database and returns
     * an object to represent it.
     *
     * @param firstName
     * @param lastName
     * @return A Employee object that represents the new record
     */
    public Employee create(String firstName, String lastName) throws CreateException, RemoteException;



    /**
     * Locates a set of Employee records in the database and returns
     * a collection of Employee objects to represent them.
     *
     * @param firstName
     * @return A collection of Employee objects that represent the records selected
     */
    public Collection findByFirstName(String firstName) throws FinderException, RemoteException;

    /**
     * Locates a set of Employee records in the database and returns
     * a collection of Employee objects to represent them.
     *
     * @param lastName
     * @return A collection of Employee objects that represent the records selected
     */
    public Collection findByLastName(String lastName) throws FinderException, RemoteException;

    /**
     * Locates a set of Employee records in the database and returns
     * a collection of Employee objects to represent them.
     *
     * @param salary
     * @return A collection of Employee objects that represent the records selected
     */
    public Collection findBySalary(int salary) throws FinderException, RemoteException;

    /**
     * Locates a Employee in the database and returns
     * an object to represent it.
     *
     * @param key
     * @return A Employee object that represents the record selected
     */
    public Employee findByPrimaryKey(Integer key) throws FinderException, RemoteException;

    /**
     * Locates a set of Employee records in the database and returns
     * a collection of Employee objects to represent them.
     *
     * @return A collection of Employee objects that represent the records selected
     */
    public Collection findAllEmployees() throws FinderException, RemoteException;

}
