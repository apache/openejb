package com.nrfx.articles.openejb;

import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import junit.framework.TestCase;

/**
 * JUnit test cases for the get/set methods
 * of the Employee EJB
 *
 * @see Employee
 * @see EmployeeHome
 */
public class EmployeeAccessorsTest extends TestCase {

    /** The bean being tested **/
    Employee employee;

    /**
     * Sets up the test case by doing a ...
     *
     *   employeeHome.findByPrimaryKey(new Integer(1));
     *
     * to find a Employee to test.
     */
    protected void setUp() throws Exception{
        InitialContext context = new InitialContext(System.getProperties());
        Object obj = context.lookup("Employee");
        EmployeeHome employeeHome = (EmployeeHome)PortableRemoteObject.narrow( obj, EmployeeHome.class);
        employee = employeeHome.findByPrimaryKey(new Integer(1));
    }

    /**
     * Tests the employee's getFirstName and setFirstName methods
     */
    public void testFirstName() {
        String expected = "Miles";
        String actual   = null;
        try{
            employee.setFirstName(expected);
        } catch (Exception e){
            fail("Can't set FirstName: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }

        try{
            actual = employee.getFirstName();
            assertEquals("The FirstName of the Employee is not the same.", expected, actual);
        } catch (Exception e){
            fail("Can't get FirstName: Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    /**
     * Tests the employee's getLastName and setLastName methods
     */
    public void testLastName() {
        String expected = "Davis";
        String actual   = null;
        try{
            employee.setLastName(expected);
        } catch (Exception e){
            fail("Can't set LastName: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }

        try{
            actual = employee.getLastName();
            assertEquals("The LastName of the Employee is not the same.", expected, actual);
        } catch (Exception e){
            fail("Can't get LastName: Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    /**
     * Tests the employee's getSalary and setSalary methods
     */
    public void testSalary() {
        int expected = (int)99;
        int actual   = (int)0;
        try{
            employee.setSalary(expected);
        } catch (Exception e){
            fail("Can't set Salary: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }

        try{
            actual = employee.getSalary();
            assertEquals("The Salary of the Employee is not the same.", expected, actual);
        } catch (Exception e){
            fail("Can't get Salary: Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    /**
     * Tests the employee's getDateHired and setDateHired methods
     */
    public void testDateHired() {
        java.sql.Date expected = new java.sql.Date(1908,2,30);
        java.sql.Date actual   = null;
        try{
            employee.setDateHired(expected);
        } catch (Exception e){
            fail("Can't set DateHired: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }

        try{
            actual = employee.getDateHired();
            assertEquals("The DateHired of the Employee is not the same.", expected, actual);
        } catch (Exception e){
            fail("Can't get DateHired: Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }



}
