package com.nrfx.articles.openejb;

import java.util.Properties;
import javax.naming.InitialContext;
import junit.framework.TestCase;

public class Example02Test extends TestCase {

    private ExampleHome ejbHome;
    private Example ejbObject;

    public void setUp() throws Exception{
        InitialContext context = new InitialContext(System.getProperties());

        Object obj = context.lookup("nrfx/examplebean");
        ejbHome = (ExampleHome)javax.rmi.PortableRemoteObject.narrow( obj, ExampleHome.class);
        ejbObject = ejbHome.create();
    }

/*-------------------------------------------------*/
/*  String                                         */
/*-------------------------------------------------*/

    public void test_returnStringObject() {
        try{
            String expected = new String("1");
            String actual = ejbObject.returnStringObject(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnStringObjectArray() {
        try{
            String[] expected = {"1","2","3"};
            String[] actual = ejbObject.returnStringObjectArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }


/*-------------------------------------------------*/
/*  Character                                      */
/*-------------------------------------------------*/
    public void test_returnCharacterObject() {
        try{
            Character expected = new Character('1');
            Character actual = ejbObject.returnCharacterObject(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnCharacterPrimitive() {
        try{
            char expected = '1';
            char actual = ejbObject.returnCharacterPrimitive(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnCharacterObjectArray() {
        try{
            Character[] expected = {new Character('1'),new Character('2'),new Character('3')};
            Character[] actual = ejbObject.returnCharacterObjectArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnCharacterPrimitiveArray() {
        try{
            char[] expected = {'1','2','3'};
            char[] actual = ejbObject.returnCharacterPrimitiveArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }


/*-------------------------------------------------*/
/*  Boolean                                        */
/*-------------------------------------------------*/

    public void test_returnBooleanObject() {
        try{
            Boolean expected = new Boolean(true);
            Boolean actual = ejbObject.returnBooleanObject(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnBooleanPrimitive() {
        try{
            boolean expected = true;
            boolean actual = ejbObject.returnBooleanPrimitive(expected);
            assertEquals(""+expected, ""+actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnBooleanObjectArray() {
        try{
            Boolean[] expected = {new Boolean(true),new Boolean(false),new Boolean(true)};
            Boolean[] actual = ejbObject.returnBooleanObjectArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnBooleanPrimitiveArray() {
        try{
            boolean[] expected = {false,true,true};
            boolean[] actual = ejbObject.returnBooleanPrimitiveArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }


/*-------------------------------------------------*/
/*  Byte                                           */
/*-------------------------------------------------*/

    public void test_returnByteObject() {
        try{
            Byte expected = new Byte("1");
            Byte actual = ejbObject.returnByteObject(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnBytePrimitive() {
        try{
            byte expected = (byte)1;
            byte actual = ejbObject.returnBytePrimitive(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnByteObjectArray() {
        try{
            Byte[] expected = {new Byte("1"),new Byte("2"),new Byte("3")};
            Byte[] actual = ejbObject.returnByteObjectArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnBytePrimitiveArray() {
        try{
            byte[] expected = {(byte)1,(byte)2,(byte)3};
            byte[] actual = ejbObject.returnBytePrimitiveArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }


/*-------------------------------------------------*/
/*  Short                                          */
/*-------------------------------------------------*/

    public void test_returnShortObject() {
        try{
            Short expected = new Short("1");
            Short actual = ejbObject.returnShortObject(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnShortPrimitive() {
        try{
            short expected = (short)1;
            short actual = ejbObject.returnShortPrimitive(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnShortObjectArray() {
        try{
            Short[] expected = {new Short("1"),new Short("2"),new Short("3")};
            Short[] actual = ejbObject.returnShortObjectArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnShortPrimitiveArray() {
        try{
            short[] expected = {(short)1,(short)2,(short)3};
            short[] actual = ejbObject.returnShortPrimitiveArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }


/*-------------------------------------------------*/
/*  Integer                                      */
/*-------------------------------------------------*/

    public void test_returnIntegerObject() {
        try{
            Integer expected = new Integer(1);
            Integer actual = ejbObject.returnIntegerObject(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnIntegerPrimitive() {
        try{
            int expected = 1;
            int actual = ejbObject.returnIntegerPrimitive(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnIntegerObjectArray() {
        try{
            Integer[] expected = {new Integer(1),new Integer(2),new Integer(3)};
            Integer[] actual = ejbObject.returnIntegerObjectArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnIntegerPrimitiveArray() {
        try{
            int[] expected = {1,2,3};
            int[] actual = ejbObject.returnIntegerPrimitiveArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }


/*-------------------------------------------------*/
/*  Long                                           */
/*-------------------------------------------------*/

    public void test_returnLongObject() {
        try{
            Long expected = new Long("1");
            Long actual = ejbObject.returnLongObject(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnLongPrimitive() {
        try{
            long expected = 1;
            long actual = ejbObject.returnLongPrimitive(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnLongObjectArray() {
        try{
            Long[] expected = {new Long("1"),new Long("2"),new Long("3")};
            Long[] actual = ejbObject.returnLongObjectArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnLongPrimitiveArray() {
        try{
            long[] expected = {1,2,3};
            long[] actual = ejbObject.returnLongPrimitiveArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }


/*-------------------------------------------------*/
/*  Float                                      */
/*-------------------------------------------------*/

    public void test_returnFloatObject() {
        try{
            Float expected = new Float("1.3");
            Float actual = ejbObject.returnFloatObject(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnFloatPrimitive() {
        try{
            float expected = 1.2F;
            float actual = ejbObject.returnFloatPrimitive(expected);
            assertEquals(expected, actual, 0.00D);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnFloatObjectArray() {
        try{
            Float[] expected = {new Float("1.1"),new Float("2.2"),new Float("3.3")};
            Float[] actual = ejbObject.returnFloatObjectArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnFloatPrimitiveArray() {
        try{
            float[] expected = {1.2F,2.3F,3.4F};
            float[] actual = ejbObject.returnFloatPrimitiveArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i , expected[i], actual[i], 0.0D);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }


/*-------------------------------------------------*/
/*  Double                                      */
/*-------------------------------------------------*/

    public void test_returnDoubleObject() {
        try{
            Double expected = new Double("1.1");
            Double actual = ejbObject.returnDoubleObject(expected);
            assertEquals(expected, actual);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnDoublePrimitive() {
        try{
            double expected = 1.2;
            double actual = ejbObject.returnDoublePrimitive(expected);
            assertEquals(expected, actual, 0.0D);
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnDoubleObjectArray() {
        try{
            Double[] expected = {new Double("1.3"),new Double("2.4"),new Double("3.5")};
            Double[] actual = ejbObject.returnDoubleObjectArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i]);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }

    public void test_returnDoublePrimitiveArray() {
        try{
            double[] expected = {1.4,2.5,3.6};
            double[] actual = ejbObject.returnDoublePrimitiveArray(expected);

            assertNotNull("The array returned is null", actual);
            assertEquals(expected.length, actual.length);
            for (int i=0; i < actual.length; i++){
                assertEquals("Array values are not equal at index "+i ,expected[i], actual[i],0.0D);
            }
        } catch (Exception e){
            fail("Received Exception "+e.getClass()+ " : "+e.getMessage());
        }
    }
}

