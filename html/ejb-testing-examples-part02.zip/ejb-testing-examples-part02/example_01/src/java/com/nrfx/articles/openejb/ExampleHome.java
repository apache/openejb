package com.nrfx.articles.openejb;

public interface ExampleHome extends javax.ejb.EJBHome {

    public Example create()
    throws javax.ejb.CreateException, java.rmi.RemoteException;
}
