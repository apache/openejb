package com.nrfx.articles.openejb;

import java.sql.Date;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import junit.framework.TestCase;

/**
 * JUnit test cases for the create methods of
 * the Employee EJB's home interface, EmployeeHome.
 *
 * @see Employee
 * @see EmployeeHome
 */
public class EmployeeCreateTest extends TestCase {

    /** The home interface of the bean **/
    EmployeeHome employeeHome;


    /**
     * Sets up the test case by getting a
     * EmployeeHome from the DomainServices object.
     */
    protected void setUp() throws Exception{
        InitialContext context = new InitialContext(System.getProperties());
        Object obj = context.lookup("Employee");
        employeeHome = (EmployeeHome)PortableRemoteObject.narrow( obj, EmployeeHome.class);
    }


    /**
     * Test case for the following create method
     *  create(String firstName, String lastName, int salary, Date dateHired)
     *
     * @see EmployeeHome#create(String, String, int, Date)
     */
    public void testCreate1(){

        /* Maps to field first_name */
        String firstName = "foo";

        /* Maps to field last_name */
        String lastName = "foo";

        /* Maps to field salary */
        int salary = 5;

        /* Maps to field date_hired */
        Date dateHired = new Date(1929,1,6);

        /* Create the new entity bean (record) */
        Employee employee = null;
        try{
            employee = employeeHome.create(firstName, lastName, salary, dateHired);
        } catch (Exception e){
            fail("Cannot create a employee object: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }

        /* Check the object retured for validity */
        try{
            assertNotNull("The new object's primary key is null.", employee.getPrimaryKey());
            assertEquals("The FirstName of the Employee is not the same.", firstName, employee.getFirstName());
            assertEquals("The LastName of the Employee is not the same.", lastName, employee.getLastName());
            assertEquals("The Salary of the Employee is not the same.", salary, employee.getSalary());
            assertEquals("The DateHired of the Employee is not the same.", dateHired, employee.getDateHired());

        } catch (Exception e){
            fail("The Employee created is not functional: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }
    }

    /**
     * Test case for the following create method
     *  create(String firstName, String lastName)
     *
     * @see EmployeeHome#create(String, String)
     */
    public void testCreate2(){

        /* Maps to field first_name */
        String firstName = "foo";

        /* Maps to field last_name */
        String lastName = "foo";

        /* Create the new entity bean (record) */
        Employee employee = null;
        try{
            employee = employeeHome.create(firstName, lastName);
        } catch (Exception e){
            fail("Cannot create a employee object: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }

        /* Check the object retured for validity */
        try{
            assertNotNull("The new object's primary key is null.", employee.getPrimaryKey());
            assertEquals("The FirstName of the Employee is not the same.", firstName, employee.getFirstName());
            assertEquals("The LastName of the Employee is not the same.", lastName, employee.getLastName());

        } catch (Exception e){
            fail("The Employee created is not functional: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }
    }


}
