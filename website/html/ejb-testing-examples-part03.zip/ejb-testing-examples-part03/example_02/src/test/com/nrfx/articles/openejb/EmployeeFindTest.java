package com.nrfx.articles.openejb;

import java.util.Collection;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import junit.framework.TestCase;

/**
 * JUnit test cases for the create methods of
 * the Employee EJB's home interface, EmployeeHome.
 *
 * @see Employee
 * @see EmployeeHome
 */
public class EmployeeFindTest extends TestCase {

    /** The home interface of the bean **/
    EmployeeHome employeeHome;

    /**
     * Sets up the test case by getting a
     * EmployeeHome from the DomainServices object.
     */
    protected void setUp() throws Exception{
        InitialContext context = new InitialContext(System.getProperties());
        Object obj = context.lookup("Employee");
        employeeHome = (EmployeeHome)PortableRemoteObject.narrow( obj, EmployeeHome.class);
    }


    /**
     * Test case for the following find method
     *  findByFirstName(String firstName)
     *
     * @see EmployeeHome#findByFirstName(String)
     */
    public void testfindByFirstName1(){

        /* Maps to field first_name */
        String firstName = "Jimmy";

        /* Find the entity bean (select the record) */
        Employee[] employees = null;
        try{
            Collection objects = employeeHome.findByFirstName(firstName);
            employees = new Employee[objects.size()];
            objects.toArray(employees);
        } catch (Exception e){
            fail("Cannot find a employee object: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }

        /**
         * Check the object retured for validity
         * Must have the same attributes as used
         * to locate the bean.
         */
        try{
            for (int i=0; i < employees.length; i++) {
                Employee employee = employees[i];
                assertNotNull("The new object's primary key is null.", employee.getPrimaryKey());
                assertEquals("The FirstName of the Employee is not the same.", firstName, employee.getFirstName());
            }
        } catch (Exception e){
            fail("The Employee found is not functional: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }
    }

    /**
     * Test case for the following find method
     *  findByLastName(String lastName)
     *
     * @see EmployeeHome#findByLastName(String)
     */
    public void testfindByLastName2(){

        /* Maps to field last_name */
        String lastName = "Baker";

        /* Find the entity bean (select the record) */
        Employee[] employees = null;
        try{
            Collection objects = employeeHome.findByLastName(lastName);
            employees = new Employee[objects.size()];
            objects.toArray(employees);
        } catch (Exception e){
            fail("Cannot find a employee object: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }

        /**
         * Check the object retured for validity
         * Must have the same attributes as used
         * to locate the bean.
         */
        try{
            for (int i=0; i < employees.length; i++) {
                Employee employee = employees[i];
                assertNotNull("The new object's primary key is null.", employee.getPrimaryKey());
                assertEquals("The LastName of the Employee is not the same.", lastName, employee.getLastName());
            }
        } catch (Exception e){
            fail("The Employee found is not functional: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }
    }

    /**
     * Test case for the following find method
     *  findBySalary(int salary)
     *
     * @see EmployeeHome#findBySalary(int)
     */
    public void testfindBySalary3(){

        /* Maps to field salary */
        int salary = 20000;

        /* Find the entity bean (select the record) */
        Employee[] employees = null;
        try{
            Collection objects = employeeHome.findBySalary(salary);
            employees = new Employee[objects.size()];
            objects.toArray(employees);
        } catch (Exception e){
            fail("Cannot find a employee object: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }

        /**
         * Check the object retured for validity
         * Must have the same attributes as used
         * to locate the bean.
         */
        try{
            for (int i=0; i < employees.length; i++) {
                Employee employee = employees[i];
                assertNotNull("The new object's primary key is null.", employee.getPrimaryKey());
                assertEquals("The Salary of the Employee is not the same.", salary, employee.getSalary());
            }
        } catch (Exception e){
            fail("The Employee found is not functional: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }
    }

    /**
     * Test case for the following find method
     *  findByPrimaryKey(Integer key)
     *
     * @see EmployeeHome#findByPrimaryKey(Integer)
     */
    public void testfindByPrimaryKey4(){

        /* Maps to field employee_id */
        Integer key = new Integer(2);

        /* Find the entity bean (select the record) */
        Employee employee = null;
        try{
            employee = employeeHome.findByPrimaryKey(key);
        } catch (Exception e){
            fail("Cannot find a employee object: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }

        /**
         * Check the object retured for validity
         * Must have the same attributes as used
         * to locate the bean.
         */
        try{
            assertNotNull("The new object's primary key is null.", employee.getPrimaryKey());
        } catch (Exception e){
            fail("The Employee found is not functional: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }
    }

    /**
     * Test case for the following find method
     *  findAllEmployees()
     *
     * @see EmployeeHome#findAllEmployees()
     */
    public void testfindAllEmployees5(){

        /* Find the entity bean (select the record) */
        Employee[] employees = null;
        try{
            Collection objects = employeeHome.findAllEmployees();
            employees = new Employee[objects.size()];
            objects.toArray(employees);
        } catch (Exception e){
            fail("Cannot find a employee object: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }

        /**
         * Check the object retured for validity
         * Must have the same attributes as used
         * to locate the bean.
         */
        try{
            for (int i=0; i < employees.length; i++) {
                Employee employee = employees[i];
                assertNotNull("The new object's primary key is null.", employee.getPrimaryKey());
            }
        } catch (Exception e){
            fail("The Employee found is not functional: Received Exception: "+e.getClass()+ " : "+e.getMessage());
        }
    }


}
