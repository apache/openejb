CREATE SEQUENCE employee_seq;

CREATE TABLE employee (
   employee_id INTEGER default employee_seq.nextval,
	first_name VARCHAR,
	last_name VARCHAR,
	salary INTEGER,
	date_hired DATE
);

INSERT INTO Employee ( first_name, last_name, salary, date_hired ) VALUES ( 'Jimmy', 'James', 2000000,   '1998-05-11' );
INSERT INTO Employee ( first_name, last_name, salary, date_hired ) VALUES ( 'Jimmy', 'Neutron', 200, '2003-05-11' );
INSERT INTO Employee ( first_name, last_name, salary, date_hired ) VALUES ( 'Jimmy', 'Kimmel', 220000,  '2001-05-11' );
INSERT INTO Employee ( first_name, last_name, salary, date_hired ) VALUES ( 'Jimmy', 'Durante', 20000, '1930-05-11' );
INSERT INTO Employee ( first_name, last_name, salary, date_hired ) VALUES ( 'Jimmy', 'Smith', 20000, '1940-05-11' );

INSERT INTO Employee ( first_name, last_name, salary, date_hired ) VALUES ( 'Rick', 'Baker', 300000, '1980-06-11' );
INSERT INTO Employee ( first_name, last_name, salary, date_hired ) VALUES ( 'Chet', 'Baker', 30000, '1950-06-14' );
INSERT INTO Employee ( first_name, last_name, salary, date_hired ) VALUES ( 'Tom', 'Baker', 3000, '1974-06-17' );



