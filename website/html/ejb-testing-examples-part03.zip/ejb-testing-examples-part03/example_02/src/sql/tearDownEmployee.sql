DROP TABLE employee;
DROP SEQUENCE employee_seq;


