package com.nrfx.articles.openejb;

import javax.ejb.EJBObject;
import java.sql.Date;
import java.rmi.RemoteException;

/**
 * Interface for the Employee EJB
 *
 * This Employee represents a record in the EMPLOYEE table.
 * It has the following persistent attributes:
 *
 * <pre>
 * ATTRIBUTE                DB FIELD
 * -----------------------  ------------------
 * firstName                first_name
 * lastName                 last_name
 * salary                   salary
 * dateHired                date_hired
 * </pre>
 *
 * Use the EmployeeHome object to create and find instances
 * of Employee.
 *
 * @see EmployeeHome
 * @see EmployeeBean
 */
public interface Employee extends EJBObject {

    /**
     * Returns the FirstName of this Employee.
     *
     * @return String the firstName of this Employee.
     */
    public String getFirstName() throws RemoteException;

    /**
     * Sets the FirstName of this Employee.
     *
     * This method will update the database
     *
     * @param firstName The firstName attribute of this Employee
     */
    public void setFirstName(String firstName) throws RemoteException;

    /**
     * Returns the LastName of this Employee.
     *
     * @return String the lastName of this Employee.
     */
    public String getLastName() throws RemoteException;

    /**
     * Sets the LastName of this Employee.
     *
     * This method will update the database
     *
     * @param lastName The lastName attribute of this Employee
     */
    public void setLastName(String lastName) throws RemoteException;

    /**
     * Returns the Salary of this Employee.
     *
     * @return int the salary of this Employee.
     */
    public int getSalary() throws RemoteException;

    /**
     * Sets the Salary of this Employee.
     *
     * This method will update the database
     *
     * @param salary The salary attribute of this Employee
     */
    public void setSalary(int salary) throws RemoteException;

    /**
     * Returns the DateHired of this Employee.
     *
     * @return Date the dateHired of this Employee.
     */
    public Date getDateHired() throws RemoteException;

    /**
     * Sets the DateHired of this Employee.
     *
     * This method will update the database
     *
     * @param dateHired The dateHired attribute of this Employee
     */
    public void setDateHired(Date dateHired) throws RemoteException;

}
