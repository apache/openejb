package com.nrfx.articles.openejb;

import java.rmi.RemoteException;

import javax.ejb.EJBException;
import javax.ejb.SessionContext;

public class ExampleBean implements javax.ejb.SessionBean{

    private String name;
    private SessionContext ejbContext;

    public String returnStringObject(String data) {
        return data;
    }

    public String[] returnStringObjectArray(String[] data) {
        return data;
    }

    /*-------------------------------------------------*/
    /*  Character                                      */
    /*-------------------------------------------------*/

    public Character returnCharacterObject(Character data) {
        return data;
    }

    public char returnCharacterPrimitive(char data) {
        return data;
    }

    public Character[] returnCharacterObjectArray(Character[] data) {
        return data;
    }

    public char[] returnCharacterPrimitiveArray(char[] data) {
        return data;
    }

    /*-------------------------------------------------*/
    /*  Boolean                                        */
    /*-------------------------------------------------*/

    public Boolean returnBooleanObject(Boolean data) {
        return data;
    }

    public boolean returnBooleanPrimitive(boolean data) {
        return data;
    }

    public Boolean[] returnBooleanObjectArray(Boolean[] data) {
        return data;
    }

    public boolean[] returnBooleanPrimitiveArray(boolean[] data) {
        return data;
    }

    /*-------------------------------------------------*/
    /*  Byte                                           */
    /*-------------------------------------------------*/

    public Byte returnByteObject(Byte data) {
        return data;
    }

    public byte returnBytePrimitive(byte data) {
        return data;
    }

    public Byte[] returnByteObjectArray(Byte[] data) {
        return data;
    }

    public byte[] returnBytePrimitiveArray(byte[] data) {
        return data;
    }

    /*-------------------------------------------------*/
    /*  Short                                          */
    /*-------------------------------------------------*/

    public Short returnShortObject(Short data) {
        return data;
    }

    public short returnShortPrimitive(short data) {
        return data;
    }

    public Short[] returnShortObjectArray(Short[] data) {
        return data;
    }

    public short[] returnShortPrimitiveArray(short[] data) {
        return data;
    }

    /*-------------------------------------------------*/
    /*  Integer                                        */
    /*-------------------------------------------------*/

    public Integer returnIntegerObject(Integer data) {
        return data;
    }

    public int returnIntegerPrimitive(int data) {
        return data;
    }

    public Integer[] returnIntegerObjectArray(Integer[] data) {
        return data;
    }

    public int[] returnIntegerPrimitiveArray(int[] data) {
        return data;
    }

    /*-------------------------------------------------*/
    /*  Long                                           */
    /*-------------------------------------------------*/

    public Long returnLongObject(Long data) {
        return data;
    }

    public long returnLongPrimitive(long data) {
        return data;
    }

    public Long[] returnLongObjectArray(Long[] data) {
        return data;
    }

    public long[] returnLongPrimitiveArray(long[] data) {
        return data;
    }

    /*-------------------------------------------------*/
    /*  Float                                          */
    /*-------------------------------------------------*/

    public Float returnFloatObject(Float data) {
        return data;
    }

    public float returnFloatPrimitive(float data) {
        return data;
    }

    public Float[] returnFloatObjectArray(Float[] data) {
        return data;
    }

    public float[] returnFloatPrimitiveArray(float[] data) {
        return data;
    }

    /*-------------------------------------------------*/
    /*  Double                                         */
    /*-------------------------------------------------*/

    public Double returnDoubleObject(Double data) {
        return data;
    }

    public double returnDoublePrimitive(double data) {
        return data;
    }

    public Double[] returnDoubleObjectArray(Double[] data) {
        return data;
    }

    public double[] returnDoublePrimitiveArray(double[] data) {
        return data;
    }

    public void setSessionContext(SessionContext ctx) throws EJBException,RemoteException {
        ejbContext = ctx;
    }
    public void ejbCreate() throws javax.ejb.CreateException{
        this.name = "nameless automaton";
    }
    public void ejbRemove() throws EJBException,RemoteException {
    }
    public void ejbActivate() throws EJBException,RemoteException {
        // Should never be called.
    }
    public void ejbPassivate() throws EJBException,RemoteException {
        // Should never be called.
    }
}
