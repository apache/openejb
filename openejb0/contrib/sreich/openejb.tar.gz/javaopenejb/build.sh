#! /bin/sh

# $Id: build.sh,v 1.8 2001/07/09 19:14:01 blevins Exp $

#   Contributions by:
#      Assaf Arkin
#      David Blevins
#      G�rald Quintana

if [ -z "$JAVA_HOME" ] ; then
  JAVA=`which java`
  if [ -z "$JAVA" ] ; then
    echo "Cannot find JAVA. Please set your PATH."
    exit 1
  fi
  JAVA_BIN=`dirname $JAVA`
  JAVA_HOME=$JAVA_BIN/..
fi

# PS stands for PATH_SEPARATOR 
PS=':'
if [ $OSTYPE = "cygwin32" ] ; then
   PS=';'
fi

JAVA=$JAVA_HOME/bin/java

CP=`echo lib/*.jar | tr ' ' ${PS}`${PS}${CP}
CP=`echo ../OpenORB-1.1.1/dist/*.jar | tr ' ' ${PS}`${PS}${CP}
CP=`echo ../RMIoverIIOP-1.1.1/dist/*.jar | tr ' ' ${PS}`${PS}${CP}
CP=`echo ../castor-0.9.3/dist/*.jar | tr ' ' ${PS}`${PS}${CP}
CP=`echo ../tyrex-0.9.8.7/dist/*.jar | tr ' ' ${PS}`${PS}${CP}
CP=`echo lib/*.zip | tr ' ' ${PS}`${PS}${CP}
CP=$JAVA_HOME/lib/tools.jar${PS}${CP}
CLASSPATH=lib/xerces-J_1.3.1.jar${PS}${CP}${PS}test/lib/junit_3.5.jar${PS}test/lib/idb_3.26.jar:$CLASSPATH

if [ A$1 = "A" ]
then
$JAVA -classpath $CLASSPATH -Dant.home=lib org.apache.tools.ant.Main jar.all -buildfile src/build.xml
else
$JAVA -classpath $CLASSPATH -Dant.home=lib org.apache.tools.ant.Main "$@" -buildfile src/build.xml
fi
