/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 * 
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 * 
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 * 
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 * 
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 * 
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 * 
 * $Id: JmsInstanceBuilder.java,v 1.3 2000/12/26 19:05:06 dmassey Exp $
 */

package org.openejb.core.jms;


import javax.jms.ConnectionFactory;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import org.openejb.DeploymentInfo;
import org.openejb.OpenEJBException;
import org.openejb.SystemException;
import org.openejb.core.jms.asf.JmsServerSession;
import org.openejb.core.jms.asf.JmsServerSessionPool;


/**
 * Responsible for creating an instance, <code>Session</code> and
 * <code>JmsServerSession</code> group.
 */

public class JmsInstanceBuilder {
	
	/** deployment information for InstanceBuilder */
	JmsDeploymentInfo	deployment;
	
    /** destination type specific helper class */
    JmsInstanceBuilder builder;
    
    /** @link dependency */
    /*#JmsDeploymentInfo lnkJmsDeploymentInfo;*/
    /*#JmsServerSession lnkJmsServerSession;*/
	
	/******************************************************************
                        CONSTRUCTOR METHODS
    *******************************************************************/
    public JmsInstanceBuilder(){
	}
	
	/**
	 * Returns a single new instance of the JmsServerSession system for
     * the specified deployment.
	 */
	public JmsServerSession buildServerSession() 
    throws OpenEJBException, SystemException {
		return builder.buildServerSession();
	}
	
	public void init(JmsDeploymentInfo deploymentInfo, JmsServerSessionPool pool) 
    throws SystemException {
		deployment = deploymentInfo;
        String  factoryName = "";
				
		// creates the JMS infrastructure necessary for building the 
		// ServerSession and instance pairs
        switch (deployment.getDestinationType()) {
            case JmsDeploymentInfo.JMS_QUEUE: 
                builder = new JmsQueueInstanceBuilder(deployment, pool);
                break;
                
            case JmsDeploymentInfo.JMS_TOPIC:   // pass through
            case JmsDeploymentInfo.JMS_DURABLE_TOPIC:
                builder = new JmsTopicInstanceBuilder(deployment, pool);
                break;                
        }	
	}	
    
    /** 
     * Starts the Connection. Begins message delivery.
     */
    public void startReceiving()
    throws OpenEJBException {
        builder.startReceiving();
    }
    
    /**
     * Stops receiving messages and closes the connection.
     */
    public void closeConnection() {
        builder.closeConnection();
    }
    
    /**
     * Looks up the item specified in the parameter.
     * Creates a new initial context if one is not provided
     *
     * @param   name    the name of the object to look up
     * @return  the object bound to <code>name</code>
     */
    protected Object lookup(String name) 
    throws SystemException {
        Context context = deployment.getJndiEnc();
        Object  object = null;

        // creates a new context if the system doesn't provide one
        if (context == null) {
            try {
            context = new InitialContext();
            } catch (NamingException e) {
                throw new org.openejb.SystemException("Could not create a JNDI context \""+deployment.getContainer()+"\" jms container failed",e);
            }
        }
        
        // performs the actual JNDI lookup
        try {
        object = context.lookup(name);
        } catch (NamingException e) {
            throw new org.openejb.SystemException("Could not find JMS Factory \""+name+"\" jms container failed",e);;
        }
        return object;
    }
}