/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: JmsTransactionScopeHandler.java,v 1.3 2001/02/06 04:29:49 dmassey Exp $
 */

package org.openejb.core.jms;


import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.Hashtable;
import javax.ejb.EnterpriseBean;
import javax.ejb.MessageDrivenBean;
import javax.jms.Message;
import javax.transaction.Status;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;
import javax.transaction.TransactionRolledbackException;
import org.openejb.ApplicationException;
import org.openejb.Container;
import org.openejb.DeploymentInfo;
import org.openejb.InvalidateReferenceException;
import org.openejb.OpenEJB;
import javax.transaction.xa.XAResource;
import javax.jms.XASession;

/*
 * @author <a href="mailto:dan@danmassey.com">Dan Massey</a>
 * @author <a href="mailto:Richard@Monson-Haefel.com">Richard Monson-Haefel</a>
*/
public class JmsTransactionScopeHandler {
    
    /** the <code>JmsContainer</code> */
    Container container;
    
    public JmsTransactionScopeHandler(Container cntr){
        container = cntr;
    }
    
    protected TransactionManager getTxMngr( ){
        return OpenEJB.getTransactionManager();
    }
    
    protected Container getContainer(){
        return container;
    }
	public void handleSystemException()throws org.openejb.SystemException{
        Transaction currentTx = null;
        try{
        currentTx = getTxMngr().getTransaction();
        } catch (javax.transaction.SystemException se){
                throw new org.openejb.SystemException(se);
        }
        if(currentTx == null)
            return;
        else{
            try{
                currentTx.rollback();
            } catch (javax.transaction.SystemException se){
                throw new org.openejb.SystemException(se);
            } 
        }
	}
    public void beforeInvoke(XASession session, JmsDeploymentInfo deployInfo)
    throws org.openejb.SystemException{
        
        try {
            if (!deployInfo.isBeanManagedTransaction()){
                byte txAttr = deployInfo.getTransactionAttribute();
                if(txAttr==DeploymentInfo.TX_REQUIRED){
                        TransactionManager txMngr = OpenEJB.getTransactionManager();
                        txMngr.begin( );
                        Transaction containerTx = txMngr.getTransaction();
                        /* the Tx Mnger will automaticlly associate the
                           new Transaction with this thread.
                        */
                        XAResource xaRsrc = session.getXAResource();
                        containerTx.enlistResource(xaRsrc);
                        /*  until the transaction is commited, the Tx Mngr will
                            be resposible for ensuring that the JMS provider
                            delivers the message in the context of a transaction
                            and that the processing of the message remains transacted
                            until the session.run() returns, which should occur after the
                            MessageListener.onMessage( ) method returns
                            (only one message per session).
                        */  
                }else if(txAttr == DeploymentInfo.TX_NOT_SUPPORTED){
                    ;//do nothing
                }
                
            }else{ // Bean Managed Transaction     
                ; // do nothing
            }
        } catch (javax.transaction.RollbackException re) {
            throw new org.openejb.SystemException(re);
        } catch (javax.transaction.SystemException se) {
            throw new org.openejb.SystemException(se);
        } catch (javax.transaction.NotSupportedException nse) {
            // This exception will never happen. Only thrown if a nested 
            // exception is attempted and is not supported by the Tx manager. 
            // Since we have already determined that the current tranaction is 
            // not active, an attempt to create a nested exception is not possible.
        }
    }
    
    public void afterInvoke(JmsDeploymentInfo deployInfo, Message message)
    throws org.openejb.SystemException{
            Transaction currentTx = null;
            try{
            currentTx = getTxMngr().getTransaction();
            } catch (javax.transaction.SystemException se){
                    throw new org.openejb.SystemException(se);
            }
            if (!deployInfo.isBeanManagedTransaction()){// if container managed transaction
                if(currentTx == null)
                    return;// no transaction to manage
                try{
                    if (currentTx.getStatus() == Status.STATUS_ACTIVE) {
                        currentTx.commit();
                    } else if (currentTx.getStatus() == Status.STATUS_MARKED_ROLLBACK) {
                        currentTx.rollback();
                    }
                } catch (javax.transaction.SystemException se){
                    throw new org.openejb.SystemException(se);
                } catch (javax.transaction.RollbackException hre) {
                    ;// do nothing. Transaction failed, but system ok.
                } catch (javax.transaction.HeuristicRollbackException hre) {                                
                    ;// do nothing. Transaction failed, but system ok.
                } catch (javax.transaction.HeuristicMixedException hre) {
                    ;// do nothing. Transaction failed, but system ok.
                }
            } else { // IF the transaction is bean managed, cleans up the transaction
                if (currentTx == null) {
                    try {
                        message.acknowledge();// This assumes client acknowlege. What if auto-acknolwage?
                    } catch (javax.jms.JMSException jmse) {
                        throw new org.openejb.SystemException("Failed message acknowledgement.",jmse);
                    }
                } else {
                    // bean managed transactions must be resolved before exiting the bean method.
                    try{
                        currentTx.rollback();
                    }catch(javax.transaction.SystemException se){
                        throw new org.openejb.SystemException(se);
                    }
                    
                    throw new org.openejb.SystemException("The bean managed transaction was not resolved before exiting the message-driven beans 'onMessage()' method.");
                }    
            }
    }
}
