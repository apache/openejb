/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: StatefulInstanceManager.java,v 1.2 2001/12/07 18:34:30 jdaniel Exp $
 */


package org.openejb.core.stateful;

import java.io.*;
import java.lang.reflect.*;
import java.rmi.RemoteException;
import java.util.*;
import javax.ejb.EJBException;
import javax.ejb.EnterpriseBean;
import javax.ejb.SessionBean;
import javax.transaction.Status;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;
import org.openejb.ApplicationException;
import org.openejb.OpenEJB;
import org.openejb.OpenEJBException;
import org.openejb.SystemException;
import org.openejb.core.EnvProps;
import org.openejb.core.Operations;
import org.openejb.core.ThreadContext;
import org.openejb.util.OpenEJBErrorHandler;
import org.openejb.util.SafeProperties;
import org.openejb.util.SafeToolkit;
import org.openejb.core.ivm.IntraVmCopyMonitor;

public class StatefulInstanceManager {

    /**
     * Represents the time-out period for a stateful bean instance in milliseconds.
     * Measured as the time between method invocations.
     */
    protected long timeOUT = 0;
    /*
       This index keeps track of all beans that are not passivated.  A bean in the 
       method ready or "method ready in transaction" pools will be in this index. Passivated
       beans are not in this index.
    */
    protected Hashtable beanINDEX = new Hashtable();
    /*
      This colleciton keeps track of all beans that are in the method ready pool and are not
      passivated.  Beans that are enrolled in a current transaction are NOT elements of this
      collection.  Only beans in the lruQUE may be passivated or timeout. 
    */
    protected BeanEntryQue lruQUE;// que of beans for LRU algorithm
    
    /*
      The passivator is responsible for writing beans to disk at passivation time. Different 
      passivators can be used and are chosen by setting the EnvProps.IM_PASSIVATOR property
      used in initialization of this instance to a the fully qualified class name of the 
      PassivationStrategy. The passivator is not responsible for invoking any callbacks or other 
      processing. Its only responsibly is to write the bean state to disk.

    */
    protected PassivationStrategy passivator;
    
    // Timeout Manager

    protected int BULK_PASSIVATION_SIZE = 100;

    protected SafeToolkit toolkit = SafeToolkit.getToolkit("StatefulInstanceManager");
    
    /******************************************************************
                        CONSTRUCTOR METHODS
    *******************************************************************/
    public StatefulInstanceManager( ){
    }

    /**********************************************************************
            InstanceManager INTERFACE METHODS
    ***********************************************************************/
    /**
     * Fully instaniates this instance manager and assigns it to the specified ContainerManager.
     * The properities passed in a re retrieved from the section of the OpenEJB XML config that defines this instance manager.
     * 
     * @param cm the ContainerManager that this instance manager is a part of
     * @param props the properties the instance manager needs to fully initialize and run
     * @throws OpenEJBException if there is a problem initializing this instance manager
     */
    public void init(Properties props)
    throws OpenEJBException{

        SafeProperties safeProps = toolkit.getSafeProperties(props);

        String passivatorClass = safeProps.getProperty(EnvProps.IM_PASSIVATOR);

        try{
            passivator = (PassivationStrategy)toolkit.newInstance(passivatorClass);
        }catch(Exception e){
            OpenEJBErrorHandler.propertyValueIsIllegal(EnvProps.IM_PASSIVATOR, passivatorClass, e.getLocalizedMessage());
        }
        passivator.init(props);

        int poolSize = safeProps.getPropertyAsInt(EnvProps.IM_POOL_SIZE, 100);
        int timeOutInMinutes = safeProps.getPropertyAsInt(EnvProps.IM_TIME_OUT,5);
        int bulkPassivationSize = safeProps.getPropertyAsInt(EnvProps.IM_PASSIVATE_SIZE,(int)(poolSize*.25));
        
        
        lruQUE = new BeanEntryQue(poolSize);
        BULK_PASSIVATION_SIZE = (bulkPassivationSize > poolSize)? poolSize: bulkPassivationSize;
        timeOUT = timeOutInMinutes*60*1000; // (minutes x 60 sec x 1000 milisec)
    }

    /**
     * Gets the ancillary state object of the instance with the specified primaryKey.
     * 
     * The Ancillary state object is used to hold additional information specific to the bean instance that is not
     * captured by the instance itself.  Example: The org.openejb.core.StatefulContainer uses a ancillary object to store the
     * client identity (unique identity of the JVM and computer) that created the stateful bean instance.
     * @param primaryKey the primary key of the bean instance
     * @return the ancillary state object
     * @throws OpenEJBException if there is a problem retrieving the ancillary state object
     * @see SessionKey
     */
    public Object getAncillaryState(Object primaryKey)
    throws OpenEJBException{
        return this.getBeanEntry(primaryKey).ancillaryState;
    }

    /**
     * Sets the ancillary state of the bean instance with the specified primaryKey
     * 
     * setting the ancillary state after modifing it is not necessary, because getAncillary state returns an object
     * reference.
     * @param primaryKey the unique key that can identify the instance being managed
     * @param ancillaryState the new ancillary state of the bean instance in this instance manager
     * @throws OpenEJBException if there is a problem setting the ancillary state object
     * @see SessionKey
     */
    public void setAncillaryState(Object primaryKey, Object ancillaryState)
    throws OpenEJBException{
        BeanEntry entry = getBeanEntry(primaryKey);
        entry.ancillaryState = ancillaryState;
        if(ancillaryState instanceof javax.transaction.Transaction)
            entry.transaction = (javax.transaction.Transaction)ancillaryState;
            
    }

    /**
     * Instantiates and returns an new instance of the specified bean class
     * @param primaryKey the unique key that can identify the instance being managed
     * @param beanClass the type of the bean's class
     * @return an new instance of the bean class
     * @throws OpenEJBException if there is a problem initializing the bean class
     * @see SessionKey
     */
    public EnterpriseBean newInstance(Object primaryKey, Class beanClass)
    throws OpenEJBException{
        return this.newInstance(primaryKey,null, beanClass);
    }

    /**
     * Instantiates and returns an new instance of the specified bean class
     * @param primaryKey the unique key that can identify the instance being managed
     * @param ancillaryState the ancillary state of the bean instance in this instance manager
     * @param beanClass the type of the bean's class
     * @return an new instance of the bean class
     * @throws OpenEJBException if there is a problem initializing the bean class
     * @see SessionKey
     */
    public EnterpriseBean newInstance(Object primaryKey, Object ancillaryState, Class beanClass)
    throws OpenEJBException{

            SessionBean bean = null;

            try{
            bean = (SessionBean)toolkit.newInstance(beanClass);
            }catch(OpenEJBException oee){
                throw (SystemException)oee;
            }

            ThreadContext thrdCntx = ThreadContext.getThreadContext();
            byte currentOp = thrdCntx.getCurrentOperation();
            thrdCntx.setCurrentOperation(Operations.OP_SET_CONTEXT);
            try{
                ((javax.ejb.SessionBean)bean).setSessionContext((javax.ejb.SessionContext)thrdCntx.getDeploymentInfo().getEJBContext());
            }catch(Exception exp){
                try{
                    /*
                    In the event of an exception, OpenEJB is required to log the exception, evict the instance,
                    and mark the transaction for rollback.  If there is a transaction to rollback, then the a
                    javax.transaction.TransactionRolledbackException must be throw to the client. Otherwise a
                    java.rmi.RemoteException is thrown to the client.
                    See EJB 1.1 specification, section 12.3.2
                    */
                    //FIXME: Log the exception
                    Transaction tx = OpenEJB.getTransactionManager().getTransaction();
                    if(tx!=null){
                        tx.setRollbackOnly();
                        throw new org.openejb.InvalidateReferenceException(new javax.transaction.TransactionRolledbackException("An exception was thrown calling ejbActivate() on the bean instance. The exception message = "+exp.getMessage()));
                    }
                }catch(Exception e){
                    throw new SystemException("A Transaction System exception was thrown while attempting to rollback the transaction due to an exception thrown while invoking ejbActivate() on the bean instance.",e);
                }
                if(exp instanceof java.rmi.RemoteException)
                    throw new org.openejb.InvalidateReferenceException(exp);
                else
                    throw new org.openejb.InvalidateReferenceException(new java.rmi.RemoteException("RuntimeException thrown durring activation of bean instance",exp));
            }finally{
                thrdCntx.setCurrentOperation(currentOp);
            }
            

            BeanEntry entry = new BeanEntry(bean,primaryKey, ancillaryState, timeOUT);

            beanINDEX.put(primaryKey, entry);
            
            
            return entry.bean;
    }

    /**
     * Gets a previously instantiated instance of the bean class with the specified primaryKey
     * @param primaryKey the unique key that can identify the instance to return
     * @return an instance of the bean class
     * @throws OpenEJBException if there is a problem retreiving the instance from the pool
     * @see SessionKey
     */
    public EnterpriseBean obtainInstance(Object primaryKey)throws OpenEJBException{
        BeanEntry entry = (BeanEntry)beanINDEX.get(primaryKey);
        if(entry == null){
            // if the bean is not in the beanINDEX then it must either be passivated or it doesn't exist.
            entry = activate(primaryKey);
            if(entry != null){
                // the bean instance was passivated
                if(entry.isTimedOut()){
                    /* Since the bean instance hasn't had its ejbActivate() method called yet, 
                       it is still considered to be passivated at this point. Instances that timeout 
                       while passivated must be evicted WITHOUT having their ejbRemove() 
                       method invoked. Section 6.6 of EJB 1.1 specification.  
                    */
                    throw new org.openejb.InvalidateReferenceException(new java.rmi.NoSuchObjectException("Timed Out"));
                }
                // invoke ejbActivate( ) on bean
                ThreadContext thrdCntx = ThreadContext.getThreadContext();
                byte currentOp = thrdCntx.getCurrentOperation();
                thrdCntx.setCurrentOperation(Operations.OP_ACTIVATE);
                
                try{
                    ((SessionBean)entry.bean).ejbActivate( );
                }catch(Exception exp){
                    try{
                        /*
                        In the event of an exception, OpenEJB is required to log the exception, evict the instance,
                        and mark the transaction for rollback.  If there is a transaction to rollback, then the a
                        javax.transaction.TransactionRolledbackException must be throw to the client. Otherwise a
                        java.rmi.RemoteException is thrown to the client.
                        See EJB 1.1 specification, section 12.3.2
                        */
                        //FIXME: Log the exception
                        Transaction tx = OpenEJB.getTransactionManager().getTransaction();
                        if(tx!=null){
                            tx.setRollbackOnly();
                            throw new org.openejb.InvalidateReferenceException(new javax.transaction.TransactionRolledbackException("An exception was thrown calling ejbActivate() on the bean instance. The exception message = "+exp.getMessage()));
                        }
                    }catch(Exception e){
                        throw new SystemException("A Transaction System exception was thrown while attempting to rollback the transaction due to an exception thrown while invoking ejbActivate() on the bean instance.",e);
                    }
                    if(exp instanceof java.rmi.RemoteException)
                        throw new org.openejb.InvalidateReferenceException(exp);
                    else
                        throw new org.openejb.InvalidateReferenceException(new java.rmi.RemoteException("RuntimeException thrown durring activation of bean instance",exp));
                }finally{
                    thrdCntx.setCurrentOperation(currentOp);
                }
                
                beanINDEX.put(primaryKey, entry);
                return entry.bean;
            }else{
                throw new org.openejb.InvalidateReferenceException(new java.rmi.NoSuchObjectException("Not Found"));
            }
        }else{// bean has been created and is pooled
            if(entry.transaction != null){ // the bean is pooled in the "tx method ready" pool.
            // session beans can only be accessed by one transaction at a time.
            // session beans involved in a transaction can not time out.
                try{
                    if(entry.transaction.getStatus() == Status.STATUS_ACTIVE){
                        // the transaction assocaite with the thread must be the same as the trasnaction associated with the bean entry
			// If the service thread changed, this test cannot work. 
                        //if(entry.transaction.equals(OpenEJB.getTransactionManager().getTransaction()))
                            return entry.bean;
                        /*else 
                            throw new ApplicationException(new javax.transaction.InvalidTransactionException());*/
                    }else{
                        // the tx assoc with the entry must have commited or rolledback since the last request.
                        // this means that the bean is not assicated with a live tx can can service the new thread.
                        entry.transaction = null;
                        return entry.bean;
                    }
                }catch(javax.transaction.SystemException se){
                    throw new org.openejb.SystemException(se);
                }catch(IllegalStateException ise){
                    throw new org.openejb.SystemException(ise);
                }catch(java.lang.SecurityException lse){
                    throw new org.openejb.SystemException(lse);
                }
            }else{// bean is pooled in the "method ready" pool.
                // locate bean and return it
                BeanEntry queEntry = lruQUE.remove(entry);// remove from Que so its not passivated while in use
                if(queEntry != null){
                    if(entry.isTimedOut()){
                        // dereference bean instance for GC
                        entry = (BeanEntry)beanINDEX.remove(entry.primaryKey );// remove frm index
                        
                        // current operation to ejbRemove
                        ThreadContext thrdCntx = ThreadContext.getThreadContext();
                        byte currentOp = thrdCntx.getCurrentOperation();
                        thrdCntx.setCurrentOperation(Operations.OP_REMOVE);
                        
                        // instances that timeout while in the method ready pool must have their ejbRemove() 
                        // method invoked before being evicted. Section 6.6 of EJB 1.1 specification.
                        try{
                            ((javax.ejb.SessionBean)entry.bean).ejbRemove();
                            //FIXME: log timeout
                        }catch(Exception e){
                            /*
                              Exceptions are processed "quietly"; they are not reported to the client since 
                              the timeout that caused the ejbRemove() operation did not, "technically", take 
                              place in the context of a client call. Logically, it may have timeout sometime 
                              before the client call.
                            */
                            // FIXME: log ejbRemove exception durring timeout.
                        }finally{
                            thrdCntx.setCurrentOperation(currentOp);
                            throw new org.openejb.InvalidateReferenceException(new java.rmi.NoSuchObjectException("Timed Out"));
                        }
                    }else{
                        return entry.bean;
                    }
                }else {
                    //byte currentOperation = ThreadContext.getThreadContext().getCurrentOperation();
                    //if(currentOperation == Operations.OP_AFTER_COMPLETION || currentOperation == Operations.OP_BEFORE_COMPLETION){
                        return entry.bean;
                    /*}else{
                        // if the entry was not in the que and its synchronization methods are not being exeuted, then its in use and this is a concurrent call. Not allowed.
                        throw new ApplicationException(new RemoteException("Concurrent calls not allowed"));
                    }*/
                }
            }
        }
    }

    /**
     * Hands an instance of the bean class over to this instance manager to be managed until 
     * the instace is needed again.
     * @param primaryKey the unique key that can identify the instance being managed
     * @param bean an instance of the bean class
     * @throws OpenEJBException if there is a problem adding the instance to the pool
     * @see SessionKey
     */
    public void poolInstance(Object primaryKey, EnterpriseBean bean)
    throws OpenEJBException{
        if(primaryKey == null || bean == null)
            throw new SystemException("Invalid arguments");

        BeanEntry entry = (BeanEntry)beanINDEX.get(primaryKey);

        if(entry == null)
            throw new SystemException("Invalid primaryKey");
        else if(entry.bean != bean)
            throw new SystemException("Invalid ID for bean");

           
        if(entry.transaction!=null && entry.transaction == entry.ancillaryState){
            // only Bean Managed Transaction beans will have their ancillary ...
            // ... state and transaction variable equal to the same object
            return;// don't put in LRU (method ready) pool.
        }else{
            try{
            entry.transaction = OpenEJB.getTransactionManager().getTransaction();
            }catch(javax.transaction.SystemException se){
                throw new org.openejb.SystemException("TransactionManager failure");
            }
                
            if(entry.transaction == null){// only put in LRU if no current transaction
                if(lruQUE.isFull( )){// is the LRU QUE full?
                    passivate();
                }
                entry.resetTimeOut();
                lruQUE.add(entry);// add it to end of Que; the most reciently used bean
            }
        }
    }

    /**
     * Permanently removes the bean instance with the specified primaryKey from this instance manager's pool
     * The primaryKey will be of type SessionKey
     * @param primaryKey the unique key that can identify the instance to be freed
     * @throws OpenEJBException if there is a problem removing the bean instance from the pool
     * @see Sessionkey
     */
    public EnterpriseBean freeInstance(Object primaryKey)
    throws org.openejb.SystemException{
        BeanEntry entry = null; 
        entry = (BeanEntry)beanINDEX.remove(primaryKey);// remove frm index
        if(entry == null){
            entry = activate(primaryKey);
        }else{
             lruQUE.remove(entry);// remove from que
        }
        
	if ( entry == null )
		return null;

        // bean instanance and entry should be dereferenced and ready for garbage collection
        return entry.bean;
    }

    /************************************************************
                    PASSIVATION
    **************************************************************/
    protected void passivate( ) throws SystemException {
        // bulk passivate the least receintly used methodReady session beans
        BeanEntry headEntry = null;
        synchronized(beanINDEX){
            
            headEntry = lruQUE.first(BULK_PASSIVATION_SIZE);// remove chain of least recently used beans
            BeanEntry temp = headEntry;
            while(temp != null){
                beanINDEX.remove(temp.primaryKey);
                temp = temp.afterMe;
            }
        
        }
        
        
        BeanEntry currentEntry = null;
        int entryCount = 0;
        ThreadContext thrdCntx = null;
        while(headEntry != null){
            if(headEntry.isTimedOut()){
                // dereference bean instance for GC
                BeanEntry badEntry = headEntry;
                headEntry = headEntry.afterMe;
                badEntry.removeFromChain();// remove from que chain
                if(thrdCntx == null)thrdCntx = ThreadContext.getThreadContext();
                byte currentOp = thrdCntx.getCurrentOperation();
                thrdCntx.setCurrentOperation(Operations.OP_REMOVE);
                try{
                    /*
                     Technically the bean is still in the method ready pool at this point so 
                     its ejbRemove() method must be processed before it can be evicted from memory.
                     Section 6.6 of EJB 1.1 specification.
                    */
                    ((javax.ejb.SessionBean)badEntry.bean).ejbRemove();
                    //FIXME: log timeout
                }catch(Exception e){
                    /*
                        Exceptions are processed "quietly"; they are not reported to the client since 
                        the timeout that caused the ejbRemove() operation did not, "technically", take 
                        place in the context of a client call.
                    */
                    // FIXME: log ejbRemove exception durring timeout.
                }finally{
                    thrdCntx.setCurrentOperation(currentOp);
                }

                //FIXME: Log a timeout
            }else{
                if(thrdCntx == null)thrdCntx = ThreadContext.getThreadContext();
                byte currentOp = thrdCntx.getCurrentOperation();
                thrdCntx.setCurrentOperation(Operations.OP_PASSIVATE);
                try{
                    // invoke ejbPassivate on bean instance
                    ((SessionBean)headEntry.bean).ejbPassivate();
                    currentEntry = headEntry;
                    headEntry = headEntry.afterMe;
                    entryCount++;
                }catch(Throwable t){
                    BeanEntry badEntry = headEntry;
                    headEntry = headEntry.afterMe;
                    badEntry.removeFromChain();// remove from que chain
                    //FIXME: Log and Register exception so it can thrown when client attempt to obtin this entry
                }finally{
                    thrdCntx.setCurrentOperation(currentOp);
                }
            }
        }

        if(entryCount>0){
            Hashtable stateTable = new Hashtable(entryCount);


            headEntry = currentEntry;
            currentEntry = null;
            while(headEntry != null){
                stateTable.put(headEntry.primaryKey,  headEntry);
                currentEntry = headEntry;
                headEntry = headEntry.beforeMe;
                currentEntry.removeFromChain();
            }
            
            /*
               the IntraVmCopyMonitor.prePssivationOperation() demarcates 
               the begining of passivation; used by EjbHomeProxyHandler, 
               EjbObjectProxyHandler, IntraVmMetaData, and IntraVmHandle 
               to deterime how serialization for these artifacts.
            */
            try{
            IntraVmCopyMonitor.prePassivationOperation();
            // pass the beans to the PassivationStrategy to write to disk.
            passivator.passivate(stateTable);
            }finally{
                // demarcate the end of passivation.
                IntraVmCopyMonitor.postPassivationOperation();
            }
                
        }
    }
    protected BeanEntry activate(Object primaryKey) throws SystemException {
         return (BeanEntry)passivator.activate(primaryKey);
    }

    protected org.openejb.InvalidateReferenceException destroy(BeanEntry entry, Exception t) 
    throws org.openejb.SystemException{

        beanINDEX.remove(entry.primaryKey);// remove frm index
        lruQUE.remove(entry);// remove from que
        if(entry.transaction != null){
            try{
            entry.transaction.setRollbackOnly();
            }catch(javax.transaction.SystemException se){
                throw new org.openejb.SystemException(se);
            }catch(IllegalStateException ise){
                throw new org.openejb.SystemException("Attempt to rollback a non-tx context",ise);
            }catch(java.lang.SecurityException lse){
                throw new org.openejb.SystemException("Container not authorized to rollback tx",lse);
            }
            return new org.openejb.InvalidateReferenceException(new javax.transaction.TransactionRolledbackException(t.getMessage()));
        }else if(t instanceof RemoteException)
            return new org.openejb.InvalidateReferenceException(t);
        else{
            EJBException ejbE = (EJBException)t;
            return new org.openejb.InvalidateReferenceException(new RemoteException(ejbE.getMessage(), ejbE.getCausedByException()));
        }


        //FIXME: Spec 12.3.6 release all resources

    }
    // HELPER METHODS

    /*
    Used by get/setAncillaryState( ) methods
    */
    protected BeanEntry getBeanEntry(Object primaryKey)
    throws OpenEJBException{
        BeanEntry entry = (BeanEntry)beanINDEX.get(primaryKey);
        if(entry == null){
            EnterpriseBean bean = this.obtainInstance(primaryKey);
            this.poolInstance(primaryKey,bean);
            entry = (BeanEntry)beanINDEX.get(primaryKey);
        }
        return entry;
    }


    /***************************************************
                    INNER CLASSS
    *****************************************************/


    class BeanEntryQue {
        BeanEntry front = null;
        BeanEntry end = null;
        int count = 0;
        int capacity = 0;// size can increase past capacity; error tollerent

        protected BeanEntryQue(int preferedCapacity){
            capacity = preferedCapacity;
        }

        protected synchronized BeanEntry  first( ){
            BeanEntry temp = front;
            front = front.afterMe;
            return remove(temp);
        }
        protected synchronized BeanEntry first(int size){
            BeanEntry first = front;
            BeanEntry last = null;
            if(size >= count){
                front = null;
                end = null;
                count = 0;
                last = first;
                while(last!=null){
                    last.inQue = false;
                    last = last.afterMe;
                }
                return first;
            }else{
                last = first;
                for(int i = 0; i < size; i++){
                    if(last.afterMe == null) break;
                    last.inQue = false;
                    last = last.afterMe;
                }
                front = last;
                //last.beforeMe = null;
		count -= size;
                return first;
            }


        }
        protected synchronized void  add(BeanEntry entry){

            if(isEmpty()){
                front = entry;
                end = entry;
            }else{
                end.afterMe = entry;
                entry.beforeMe = end;
                end = entry;
            }
            entry.inQue = true;
            count++;
        }
        protected boolean isFull( ){
            return (count >= capacity);
        }
        protected boolean contains(BeanEntry entry){
            return entry.inQue;
        }
        protected boolean isEmpty( ){
            return (count == 0);
        }
        protected synchronized BeanEntry remove(BeanEntry entry){
            if(isEmpty() || !contains(entry))
                return null;
            
            if(entry == front){
                front = entry.afterMe;
            }
            
            if(entry == end){
                end = entry.beforeMe;
            }
            
            entry.removeFromChain( );

            entry.inQue = false;
            count--;
            return entry;
        }
    }

}

