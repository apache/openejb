/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: JmsContainer.java,v 1.8 2001/05/17 20:28:30 rmonson Exp $
 */

package org.openejb.core.jms;


import java.util.HashMap;
import java.util.Properties;
import org.openejb.Container;
import org.openejb.DeploymentInfo;
import org.openejb.OpenEJBException;
import org.openejb.SystemException;
import org.openejb.core.EnvProps;
import org.openejb.core.jms.asf.JmsServerSessionPool;
import org.openejb.util.SafeProperties;
import org.openejb.util.SafeToolkit;


public class JmsContainer implements org.openejb.Container{

    /** creates initial message-driven session environments */
    JmsConnectionBuilder connectionBuilder;

    /** contains deployment information for each <code>MessageDrivenBean</code> deployed to this container */
    HashMap deploymentRegistry;

    /** the server unique id for this container */
    Object containerID = null;

    /** manages the transactional scope according to the bean's transaction attributes */
    JmsTransactionScopeHandler txScopeHandler;

    /** set of {@link ServerSessionPool}s in this container */
    JmsServerSessionPool pools[];


    /**
     * Construct this container with the specified container id, deployments, container manager and properties.
     * The properties can include the class name of the preferred InstanceManager, org.openejb.core.entity.EntityInstanceManager
     * is the default. The properties should also include the properties for the instance manager.
     *
     * @param id the unique id to identify this container in the ContainerSystem
     * @param registry a hashMap of bean delpoyments that this container will be responsible for
     * @param mngr the ContainerManager for this container
     * @param properties the properties this container needs to initialize and run
     * @throws OpenEJBException if there is a problem constructing the container
     * @see org.openejb.Container
     */
    public void init(Object id, HashMap registry, Properties properties)
    throws org.openejb.OpenEJBException{
        containerID = id;
        deploymentRegistry = registry;

        if (properties == null) properties = new Properties();

        // The ConnectionBuilder is broken out as a separate Class to allow for
        // modular replacement of the entire ASF system that subclasses the
        // JmsXXX system.
        SafeToolkit toolkit = SafeToolkit.getToolkit("JmsContainer");
        SafeProperties safeProps = toolkit.getSafeProperties(properties);
        try{
        String className = safeProps.getProperty(EnvProps.CB_CLASS_NAME, "org.openejb.core.jms.JmsConnectionBuilder");
        connectionBuilder =(JmsConnectionBuilder)Class.forName(className).newInstance();
        }catch(Exception e){
            throw new org.openejb.SystemException("Initialization of JmsConnectionBuilder for the \""+containerID+"\" jms container failed",e);
        }

        // Supplies a transaction scope handler
        txScopeHandler = new JmsTransactionScopeHandler(this);

        // Builds the necessary ASF infrastructure for each deployment
        connectionBuilder.init(this, properties);
        pools = connectionBuilder.build();
    }

    //===============================
    // begin Container Implementation
    //

    /**
     * Gets the <code>DeploymentInfo</code> objects for all the beans deployed in this container.
     *
     * @return an array of DeploymentInfo objects
     * @see org.openejb.DeploymentInfo
     * @see org.openejb.ContainerSystem#deployments() ContainerSystem.deployments()
     */
    public DeploymentInfo [] deployments(){
        return (DeploymentInfo [])deploymentRegistry.values().toArray(new DeploymentInfo[deploymentRegistry.size()]);
    }

    /**
     * Gets the <code>DeploymentInfo</code> object for the bean with the specified deployment id.
     *
     * @param id the deployment id of the deployed bean.
     * @return the DeploymentInfo object associated with the bean.
     * @see org.openejb.DeploymentInfo
     * @see org.openejb.ContainerSystem#getDeploymentInfo(Object) ContainerSystem.getDeploymentInfo
     * @see org.openejb.DeploymentInfo#getDeploymentID()
     */
    public DeploymentInfo getDeploymentInfo(Object deploymentID){
        return (DeploymentInfo)deploymentRegistry.get(deploymentID);
    }
    /**
     * Gets the type of container (STATELESS, STATEFUL, ENTITY, or MESSAGE_DRIVEN
     *
     * @return id type bean container
     */
    public int getContainerType( ){
        return Container.MESSAGE_DRIVEN;
    }

    /**
     * Gets the id of this container.
     *
     * @return the id of this container.
     * @see org.openejb.DeploymentInfo#getContainerID() DeploymentInfo.getContainerID()
     */
    public Object getContainerID(){
        return containerID;
    }

    /**
     * Adds a bean to this container.
     * @param deploymentId the deployment id of the bean to deploy.
     * @param info the DeploymentInfo object associated with the bean.
     * @throws org.openejb.OpenEJBException
     *      Occurs when the container is not able to deploy the bean for some
     *      reason.
     */
    public void deploy(Object deploymentID, DeploymentInfo info) throws OpenEJBException {
        HashMap registry = (HashMap)deploymentRegistry.clone();
        registry.put(deploymentID, info);
        deploymentRegistry = registry;
    }

    // end Container Implementation
    //====================================


    //============================================
    // begin methods unique to this implementation
    //

    /**
     * Gets the <code>JmsDeploymentInfo</code> objects for all the beans deployed in this container.
     *
     * @return an array of JmsDeploymentInfo objects
     * @see org.openejb.core.jms.JmsDeploymentInfo
     * @see org.openejb.ContainerSystem#deployments() ContainerSystem.deployments()
     */
    public JmsDeploymentInfo [] getJmsDeployments(){
        return (JmsDeploymentInfo [])deploymentRegistry.values().toArray(new JmsDeploymentInfo[deploymentRegistry.size()]);
    }

    /**
     * Returns the set of <code>JmsServerSessionPools</code> in this Container.
     *
     * @return array of <code>JmsServerSessionPool</code>s
     * @see org.openejb.core.jms.asf.JmsServerSessionPool
     */
    public JmsServerSessionPool[] getServerSessionPools(){
        return pools;
    }

    /**
     * Returns the <code>JmsTransactionScopeHandler</code> for this Container.
     *
     * @return the JmsTransactionScopeHandler
     */
    public JmsTransactionScopeHandler getTransactionScopeHandler(){
        return txScopeHandler;
    }

    //
    // end methods unique to this implementation
    //================================================
}
