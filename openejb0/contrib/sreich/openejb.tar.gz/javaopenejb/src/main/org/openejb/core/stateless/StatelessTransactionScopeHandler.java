/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: StatelessTransactionScopeHandler.java,v 1.7 2001/03/21 02:30:09 blevins Exp $
 */
package org.openejb.core.stateless;

import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.Hashtable;
import javax.ejb.EnterpriseBean;
import javax.transaction.Status;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;
import javax.transaction.TransactionRolledbackException;
import org.openejb.ApplicationException;
import org.openejb.Container;
import org.openejb.DeploymentInfo;
import org.openejb.InvalidateReferenceException;
import org.openejb.core.ThreadContext;

public class StatelessTransactionScopeHandler extends org.openejb.core.TransactionScopeHandler{
    
    
    StatelessInstanceManager instanceManager;
    
    
    public StatelessTransactionScopeHandler(Container cntr, StatelessInstanceManager mngr){
        super(cntr);
        instanceManager = mngr;
    }
    protected void discardBeanInstance(EnterpriseBean bean, ThreadContext threadContext){
	org.openejb.OpenEJB.getApplicationServer().discardCurrentBean();
        instanceManager.freeInstance(threadContext,bean);    
    }
    protected void afterBeginBMT(Transaction currentTx, ThreadContext threadContext)
    throws org.openejb.SystemException{
        // bean managed transacitons must be resolved before exiting the bean method.
        try{
            currentTx.rollback();
        }catch(javax.transaction.SystemException se){
            throw new org.openejb.SystemException(se);
        }
        
        throw new org.openejb.SystemException("The bean managed transaction was not resolved before exiting the stateless beans method");
        
    }
    public Transaction beforeInvoke(Method method, javax.ejb.EnterpriseBean bean,ThreadContext threadContext)
    throws org.openejb.SystemException, org.openejb.ApplicationException{
        
        DeploymentInfo deployInfo = threadContext.getDeploymentInfo();
        
        Transaction originalTx = null;
        try{
            if(deployInfo.isBeanManagedTransaction()){
                // if no transaction ---> suspend returns null
                originalTx = getTxMngr( ).suspend();
            }else{// if container managed transactions
                // deligate work to superclass org.openejb.core.TrasnactionScopeHandler
                originalTx = super.beforeInvoke(method,bean,threadContext);
            }
            return originalTx;
        
        }catch(javax.transaction.SystemException se){
            throw new org.openejb.SystemException(se);
        }
    }
}
