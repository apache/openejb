/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: StatefulTransactionScopeHandler.java,v 1.2 2001/12/06 18:41:55 jdaniel Exp $
 */


package org.openejb.core.stateful;

import java.lang.reflect.Method;
import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.Hashtable;
import javax.ejb.EnterpriseBean;
import javax.transaction.Status;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;
import javax.transaction.TransactionRolledbackException;
import org.openejb.ApplicationException;
import org.openejb.Container;
import org.openejb.DeploymentInfo;
import org.openejb.InvalidateReferenceException;
import org.openejb.core.Operations;
import org.openejb.core.ThreadContext;
import org.openejb.core.TransactionManagerWrapper;

public class StatefulTransactionScopeHandler extends org.openejb.core.TransactionScopeHandler{
    
    StatefulInstanceManager instanceManager;
    Hashtable synchronizationTable = new Hashtable();
    
    
    public boolean register(ThreadContext threadContext)
    throws javax.transaction.SystemException, javax.transaction.RollbackException {
        SyncronizationManager sm = (SyncronizationManager)synchronizationTable.get(getTxMngr( ).getTransaction());
        if(sm==null){
            sm = new SyncronizationManager();
            synchronizationTable.put(getTxMngr( ).getTransaction(),sm);
        }else if(sm.contexts.containsKey(threadContext.getPrimaryKey())){
            return false;// don't register again
        }
       /* Register with the transaction manager; may throw TransactionRollbackException
        * Rregistering the sync as priority one ensures that it will be handled before lower priority sync objects. 
        * See TransactionManagerWrapper for more details.
        */
        ((TransactionManagerWrapper.TransactionWrapper)getTxMngr( ).getTransaction()).registerSynchronization(sm,1);
        // add the current MethodContext to the SyncronizationManager
        sm.contexts.put(threadContext.getPrimaryKey(),threadContext);
        
        return true;// bean has been registered
        
    }
    public StatefulTransactionScopeHandler(Container cntr, StatefulInstanceManager mngr){
        super(cntr);
        instanceManager = mngr;
    }
    
    protected void discardBeanInstance(EnterpriseBean bean, ThreadContext threadContext)
    throws org.openejb.SystemException{
        Object primaryKey = threadContext.getPrimaryKey();
	org.openejb.OpenEJB.getApplicationServer().discardCurrentBean();
        instanceManager.freeInstance(primaryKey);
    }
    protected void afterBeginBMT(Transaction currentTx, ThreadContext threadContext)
    throws org.openejb.SystemException, org.openejb.ApplicationException{
        Transaction bmtx = null;
        try{
            int txStatus = currentTx.getStatus();
            if(txStatus == Status.STATUS_ACTIVE)
                bmtx = getTxMngr().suspend();
            else if(txStatus == Status.STATUS_MARKED_ROLLBACK) 
                getTxMngr().rollback();
                                
        }catch(javax.transaction.SystemException se){
            throw new org.openejb.SystemException(se);
        }
        try{
            instanceManager.setAncillaryState(threadContext.getPrimaryKey(),bmtx);
        }catch(org.openejb.OpenEJBException oee){
            if(oee instanceof org.openejb.SystemException)
                throw (org.openejb.SystemException)oee;
            else if(oee instanceof org.openejb.ApplicationException)
                throw (org.openejb.ApplicationException)oee;
            else
                throw new org.openejb.SystemException(oee.getMessage(), oee.getRootCause());
        }
                       
    }
    /**
    * For Stateful beans this method is overridden in the StatefulTrasactionScopeHandler.
    * In the advent that the bean throws a system exception the container will 
    * throw the exceptionToReport (TransactionRollbackException or RemoteException) 
    * wrapped in a InvalidateReferenceException.
    *
    * Only Stateful beans need to invalidate the reference when a system exception is encountered.
    */
    protected void systemExceptionPolicy(Throwable exceptionToReport) throws InvalidateReferenceException, ApplicationException{
        // for stateful beans the proxy must be invalidated when the bean throws a system exception
        // the exception is reported to the client as a exceptionToReport (either a RemoteException or TransactionRollBackException. )
        throw new InvalidateReferenceException(exceptionToReport);
    }
    
    public void afterInvoke(Method method, EnterpriseBean bean, ThreadContext threadContext, Transaction originalTx)
    throws org.openejb.ApplicationException, org.openejb.SystemException{

        try{
   
            Transaction currentTx = getTxMngr( ).getTransaction();
            
            //IF their is not current transaciton but there was a trasnaction orginally then the orignal tx must be resumed.
            if(currentTx == null){
                if( originalTx!=null){
                try{
                    getTxMngr( ).resume(originalTx);
                }catch(javax.transaction.InvalidTransactionException ite){
                    // do nothing if the client's tx has become invalid
                    // log exception
                }
                }
            // IF the current transaction doesn't equal the starting transaction THEN a new transaction was started when the method was invoked
            // This means that the transaction scope is delimited by the bean method; a new transaction context was created for the method invocation.
            }else if(!currentTx.equals(originalTx)){ 
                    if(threadContext.getDeploymentInfo().isBeanManagedTransaction()){
                        afterBeginBMT(currentTx,threadContext);
                    }else{
                        int txStatus = currentTx.getStatus();
                        if(txStatus == Status.STATUS_ACTIVE){
                            try{
                                currentTx.commit();
                            }catch(javax.transaction.RollbackException hre){
                                throw new ApplicationException(new javax.transaction.TransactionRolledbackException());
                            }catch(javax.transaction.HeuristicRollbackException hre){
                                throw new ApplicationException(new javax.transaction.TransactionRolledbackException());
                            }catch(javax.transaction.HeuristicMixedException hre){
                                throw new ApplicationException(new javax.transaction.TransactionRolledbackException());
                            }
                        }
                        else if(txStatus == Status.STATUS_MARKED_ROLLBACK){
                                currentTx.rollback();
                        }
                    }                    
                    
                    if(originalTx!=null){
                        try{
                            getTxMngr( ).resume(originalTx);
                        }catch(javax.transaction.InvalidTransactionException ite){
                            // do nothing if the client's tx has become invalid
                            // log exception
                        }
                    }
            }
        }catch(javax.transaction.SystemException se){
            throw new org.openejb.SystemException(se);
        }
        
    }
    public Transaction beforeInvoke(Method method, javax.ejb.EnterpriseBean bean,ThreadContext threadContext)
    throws org.openejb.SystemException, org.openejb.ApplicationException{
        
        DeploymentInfo deployInfo = threadContext.getDeploymentInfo();
        
        Transaction originalTx = null;
        try{
        if(deployInfo.isBeanManagedTransaction()){
            // if no transaction ---> suspend returns null
            originalTx = getTxMngr( ).suspend();
            Transaction bmtx = null;
            try{
            bmtx = (Transaction)instanceManager.getAncillaryState(threadContext.getPrimaryKey());
            }catch(org.openejb.OpenEJBException oee){
                if(oee instanceof org.openejb.SystemException)
                    throw (org.openejb.SystemException)oee;
                else if(oee instanceof org.openejb.ApplicationException)
                    throw (org.openejb.ApplicationException)oee;
                else
                    throw new org.openejb.SystemException(oee.getMessage(), oee.getRootCause());
            }
            if(bmtx != null && bmtx.getStatus() == Status.STATUS_ACTIVE)
                try{
                getTxMngr( ).resume(bmtx);
                }catch(javax.transaction.InvalidTransactionException ite){
                    // transaction was invalid. Do nothing, because bean manages the tx
                }
        }else{// if container managed transactions
            // deligate work to superclass org.openejb.core.TrasnactionScopeHandler
            originalTx = super.beforeInvoke(method,bean,threadContext);
            byte txAttr = deployInfo.getTransactionAttribute(method);
            
            if( bean instanceof javax.ejb.SessionSynchronization 
                && txAttr != DeploymentInfo.TX_NEVER 
                && txAttr != DeploymentInfo.TX_NOT_SUPPORTED 
                && !(txAttr == DeploymentInfo.TX_SUPPORTS && originalTx == null)
            ){
                try{
                    if(this.register(threadContext)){
                        threadContext.setCurrentOperation(Operations.OP_AFTER_BEGIN);
                        ((javax.ejb.SessionSynchronization)bean).afterBegin();
                        threadContext.setCurrentOperation(Operations.OP_BUSINESS);
                    }
                }catch(javax.transaction.RollbackException tre){
                    // transaction was rolled back before bean could be registered
                    throw new ApplicationException(new javax.transaction.TransactionRolledbackException());
                }catch(Exception e){
                    Transaction tx = getTxMngr( ).getTransaction();
                    if(tx!=null)
                        tx.setRollbackOnly( );
                    try{
                        instanceManager.freeInstance(threadContext.getPrimaryKey());
                    }catch(org.openejb.OpenEJBException oee){
                        // stateful session interface doesnt throw ane exception
                    }
                    throw new ApplicationException(new javax.transaction.TransactionRolledbackException());
                    
                }
            }
        }
        return originalTx;
        
        }catch(javax.transaction.SystemException se){
            throw new org.openejb.SystemException(se);
        }
    }
    public  class SyncronizationManager implements javax.transaction.Synchronization{
         public  java.util.HashMap contexts = new java.util.HashMap();
         
         public void afterCompletion(int status){
            Object [] keys = contexts.keySet().toArray();
            for(int i = 0; i < keys.length; i++){
                
                // Have to reassocaite the original method context with the thread before invoking
                ThreadContext threadContext = (ThreadContext)contexts.get(keys[i]);
                ThreadContext.setThreadContext(threadContext);
                
                // get the bean by its method invocation
                try{
                    /*
                    * the operation must be set before the instance is obtained from the pool, so 
                    * that the instance manager doesn't mistake this as a concurrent access.
                    */
                    threadContext.setCurrentOperation(Operations.OP_AFTER_COMPLETION);
                    javax.ejb.SessionSynchronization bean = (javax.ejb.SessionSynchronization)instanceManager.obtainInstance(keys[i]);
                    bean.afterCompletion((status==Status.STATUS_COMMITTED?true:false));
                }catch(Exception e){
                    // destroy instance if exception thrown
                    try{
                        instanceManager.freeInstance(keys[i]);
                    }catch(org.openejb.OpenEJBException oee){
                        // stateful session interface doesnt throw ane exception
                    }
                }
            }
         }
         
         public void beforeCompletion(){
            Object [] keys = contexts.keySet().toArray();
            for(int i = 0; i < keys.length; i++){
                // Have to reassocaite the original method context with the thread before invoking
                ThreadContext threadContext = (ThreadContext)contexts.get(keys[i]);
                ThreadContext.setThreadContext(threadContext);
                
                // get the bean by its method invocation
                try{
                    /*
                    * the operation must be set before the instance is obtained from the pool, so 
                    * that the instance manager doesn't mistake this as a concurrent access.
                    */
                    threadContext.setCurrentOperation(Operations.OP_BEFORE_COMPLETION);
                    javax.ejb.SessionSynchronization bean = (javax.ejb.SessionSynchronization)instanceManager.obtainInstance(keys[i]);
                    bean.beforeCompletion();
                }catch(Exception e){
			e.printStackTrace();
                    // attempt to set the transaction for rollback
                    try{
                    Transaction tx = StatefulTransactionScopeHandler.this.getTxMngr( ).getTransaction();
                    if(tx!=null)tx.setRollbackOnly( );
                    }catch(Exception e2){
                        ;//do nothing
                    }
                    
                    // destroy instance if exception thrown
                    try{
                        instanceManager.freeInstance(keys[i]);
                    }catch(org.openejb.OpenEJBException oee){
                        // stateful session interface doesnt throw ane exception
                    }
                }
            }
         }
    }
    
}
