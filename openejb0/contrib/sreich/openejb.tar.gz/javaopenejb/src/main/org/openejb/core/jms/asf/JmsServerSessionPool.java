/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: JmsServerSessionPool.java,v 1.3 2000/12/27 05:28:14 dmassey Exp $
 */

package org.openejb.core.jms.asf;


import java.util.LinkedList;
import java.util.Properties;
import javax.jms.ConnectionConsumer;
import javax.jms.JMSException;
import javax.jms.ServerSession;
import javax.jms.ServerSessionPool;
import org.openejb.DeploymentInfo;
import org.openejb.OpenEJBException;
import org.openejb.SystemException;
import org.openejb.core.EnvProps;
import org.openejb.core.jms.JmsContainer;
import org.openejb.core.jms.JmsDeploymentInfo;
import org.openejb.core.jms.JmsInstanceBuilder;
import org.openejb.util.SafeProperties;
import org.openejb.util.SafeToolkit;


/**
 * This server session pool handles message-driven bean instances and JMS sessions
 * for a single message-driven bean deployment. Each bean class has a pool limit. 
 *
 * Automatic pool reduction will require the the ejbRemove method be invoked.
 * <code>setSessionContext()</code> must be done within the instance manager
 */

public class JmsServerSessionPool implements ServerSessionPool {
	
    /** 
     * optimal maximum size of ServerSession pool - 
     * OpenEJB's Message-Driven Bean implementation does not use strict pooling
     */
    int poolLimit;
    
    /** deployment info for the MessageDrivenBean deployed to this ServerSessionPool */
    JmsDeploymentInfo	ejbDeployment;
	
    /** parent container */
    JmsContainer	jmsContainer;
	
    /** instance and session builder */
    JmsInstanceBuilder	instanceBuilder;
    
    /** the actual pool */
    LinkedList  pool;
    
    /** used for properties */
    protected SafeToolkit toolkit = SafeToolkit.getToolkit("JmsContainer");

    /******************************************************************
                        CONSTRUCTOR METHODS
    *******************************************************************/
    public JmsServerSessionPool(){
    }

    //============================================
    // begin ServerSessionPool implementation
    //

    public ServerSession getServerSession( )
    throws JMSException {
		JmsServerSession   serverSession = null;
        
        // Synchronized only around a take from the pool
        synchronized (pool) {
            if (!pool.isEmpty()) {
                serverSession = (JmsServerSession) pool.removeFirst();
            }
        }
        
        // Creates a new session if the pool is empty
        if (serverSession == null) {
            try {
                serverSession = instanceBuilder.buildServerSession();
            } catch (OpenEJBException e) {
                throw new JMSException("Can't create new ServerSession");
            }
            
        }
        
        return (ServerSession) serverSession;
    }
	
    //
    // end methods unique to this implementation
    //================================================
	
    //============================================
    // begin methods unique to this implementation
    //
	
    /**
     * Starts the pool by creating the minimum number of instances specified
     * by the DeploymentInfo. The default is 1 instance.
     * @param	container	the parent container
     * @param	deployment	the deployment info for the MessageDrivenBean
     *						managed by this ServerSessionPool
     */
    public void init(JmsContainer container, JmsDeploymentInfo deployment, Properties props)
    throws OpenEJBException, SystemException {
        jmsContainer = container;
        ejbDeployment = deployment;

        // Get the pool limit -- not strict
        SafeProperties safeProps = toolkit.getSafeProperties(props);
        poolLimit = safeProps.getPropertyAsInt(EnvProps.IM_POOL_SIZE, 10);
        
        // creates the pool and adds the first bean instance,
        // then starts the Connection
        pool = new LinkedList();
        instanceBuilder = new JmsInstanceBuilder();
        instanceBuilder.init(deployment, this);
        for (int i = 0; i < 3; i++) { // Magic Number - 3 initial instances - use env-entry to supply with default
            synchronized (pool) {
                pool.addLast(instanceBuilder.buildServerSession());
            }
        }
        instanceBuilder.startReceiving();
    }

    // pool management code
    public void returnServerSession(JmsServerSession serverSession){
        if (serverSession != null) {
            if (pool.size() >= poolLimit) {
                serverSession.free();
            } else {
                synchronized (pool) {
                    pool.addLast(serverSession);
                }
            }
        }   
    }
		
    //
    // end methods unique to this implementation
    //================================================
}
