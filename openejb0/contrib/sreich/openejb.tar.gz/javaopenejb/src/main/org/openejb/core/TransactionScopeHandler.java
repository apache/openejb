/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: TransactionScopeHandler.java,v 1.27 2001/03/09 18:41:19 rmonson Exp $
 */


package org.openejb.core;


import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.Hashtable;

import javax.ejb.EnterpriseBean;
import javax.transaction.Status;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;
import javax.transaction.TransactionRolledbackException;

import org.openejb.ApplicationException;
import org.openejb.Container;
import org.openejb.DeploymentInfo;
import org.openejb.InvalidateReferenceException;
import org.openejb.core.ThreadContext;
import org.openejb.OpenEJB;

public abstract class TransactionScopeHandler {
    
    Container container;
    
    protected TransactionManager getTxMngr( ){
        return OpenEJB.getTransactionManager();
    }
    protected Container getContainer(){
        return container;
    }
    
    public TransactionScopeHandler(Container cntr){
        container = cntr;
    }  
    public Transaction beforeInvoke(Method method, javax.ejb.EnterpriseBean bean,ThreadContext threadContext)
    throws org.openejb.SystemException, org.openejb.ApplicationException{
        DeploymentInfo deployInfo = threadContext.getDeploymentInfo();
        Transaction originalTx = null;
        try{
            byte txAttr = deployInfo.getTransactionAttribute(method);
            switch(txAttr){
                case DeploymentInfo.TX_NEVER :
                    if(getTxMngr( ).getTransaction() != null)
                        throw new ApplicationException(new java.rmi.RemoteException("Transactions not supported"));
                case DeploymentInfo.TX_NOT_SUPPORTED :
                        // if no transaction ---> suspend returns null
                        originalTx = getTxMngr( ).suspend();
                        break;
                case DeploymentInfo.TX_SUPPORTS :
                        originalTx = getTxMngr( ).getTransaction();
                        break;
                case DeploymentInfo.TX_REQUIRED :
                        if(getTxMngr( ).getTransaction()==null){
                            this.beginTransaction();
                            originalTx = null;
                        }else
                            originalTx = getTxMngr( ).getTransaction();
                        break;
                case DeploymentInfo.TX_REQUIRES_NEW :
                        if(getTxMngr( ).getTransaction()==null){
                            this.beginTransaction();
                            originalTx = null;
                        }else{
                            originalTx = getTxMngr( ).suspend();
                            this.beginTransaction();
                        }
                        break;
                case  DeploymentInfo.TX_MANDITORY :
                        if(getTxMngr( ).getTransaction()==null)
                            throw new ApplicationException(new javax.transaction.TransactionRequiredException());
                        else
                            originalTx = getTxMngr( ).getTransaction();
                        break;
            }
            
            
            return originalTx;
        
        }catch(javax.transaction.SystemException se){
            throw new org.openejb.SystemException(se);
        }
    }
    protected void beginTransaction()throws javax.transaction.SystemException{
            try{
            getTxMngr( ).begin();
            }catch(javax.transaction.NotSupportedException nse){
                /* 
                This exception will never happen. Only thrown if a nested 
                exception is attempted and is not supported by the Tx manager. 
                Since we have already determined that the current tranaction is 
                not active, an attempt to create a nested exception is not possible.
                */
            }
    }
    
    public void afterInvoke(Method method, EnterpriseBean bean, ThreadContext threadContext,Transaction originalTx)
    throws org.openejb.ApplicationException, org.openejb.SystemException{
        try{
   
            Transaction currentTx = getTxMngr( ).getTransaction();
            
            //IF their is not current transaciton but there was a trasnaction orginally then the orignal tx must be resumed.
            if(currentTx == null){
                if( originalTx!=null){
                try{
                    getTxMngr( ).resume(originalTx);
                }catch(javax.transaction.InvalidTransactionException ite){
                    // do nothing if the client's tx has become invalid
                    // log exception
                }
                }
            // IF the current transaction doesn't equal the starting transaction THEN a new transaction was started when the method was invoked
            // This means that the transaction scope is delimited by the bean method; a new transaction context was created for the method invocation.
            }else if(!currentTx.equals(originalTx)){ 
                    
                    int txStatus = currentTx.getStatus();
                    if(threadContext.getDeploymentInfo().isBeanManagedTransaction()){
                        afterBeginBMT(currentTx, threadContext);
                    }else{
                        if(txStatus == Status.STATUS_ACTIVE){
                            try{
                                currentTx.commit();
                            }catch(javax.transaction.RollbackException hre){
                                throw new ApplicationException(new javax.transaction.TransactionRolledbackException());
                            }catch(javax.transaction.HeuristicRollbackException hre){
                                throw new ApplicationException(new javax.transaction.TransactionRolledbackException());
                            }catch(javax.transaction.HeuristicMixedException hre){
                                throw new ApplicationException(new javax.transaction.TransactionRolledbackException());
                            }
                        }
                        else if(txStatus == Status.STATUS_MARKED_ROLLBACK){
                                currentTx.rollback();
                        }
                    }                    
                    
                    if(originalTx!=null){
                        try{
                            getTxMngr( ).resume(originalTx);
                        }catch(javax.transaction.InvalidTransactionException ite){
                            // do nothing if the client's tx has become invalid
                            // log exception
                        }
                    }
            }
        }catch(javax.transaction.SystemException se){
            throw new org.openejb.SystemException(se);
        }
        
    }
    public void handleSystemException(Method method,EnterpriseBean bean, ThreadContext threadContext, Transaction originalTx, Throwable throwable)
    throws org.openejb.ApplicationException, org.openejb.SystemException, org.openejb.InvalidateReferenceException{
        // set the isSystemException boolean to *true* and execute handleException
        handleException(true, method, bean, threadContext, originalTx, throwable);
    }
    public void handleApplicationException(Method method,EnterpriseBean bean, ThreadContext threadContext, Transaction originalTx, Throwable throwable)
    throws org.openejb.ApplicationException, org.openejb.SystemException, org.openejb.InvalidateReferenceException{
        // set the isSystemException boolean to *false* and execute handleException
        handleException(false, method, bean, threadContext, originalTx, throwable);
    }
    
    protected void handleException(boolean isSystemException, Method method,EnterpriseBean bean, ThreadContext threadContext, Transaction originalTx, Throwable throwable)
    throws org.openejb.ApplicationException, org.openejb.SystemException, org.openejb.InvalidateReferenceException{
        
        
        DeploymentInfo deployInfo = threadContext.getDeploymentInfo();
        Transaction currentTx = null;
        try{
            currentTx = getTxMngr( ).getTransaction();
        }catch(javax.transaction.SystemException se){
            throw new org.openejb.SystemException(se);
        }
        
        /*
        * The EJB 2.0 policy for bean managed transaction requires that application exceptions be re-thrown
        * to the client and that system exceptions result in the destruction of the instance, rollback of
        * the transaction, and a RemoteException to the client.  The client's stub is remains valid.
        */
        if(deployInfo.isBeanManagedTransaction()){
            if(isSystemException){
                discardBeanInstance(bean, threadContext);
                if(currentTx!=null){
                    
                    try{
                    currentTx.setRollbackOnly();
                    }catch(javax.transaction.SystemException se){
                        throw new org.openejb.SystemException(se);
                    }
                    if(originalTx != null)
                    try{
                        getTxMngr().resume(originalTx);
                    }catch(javax.transaction.SystemException se){
                        throw new org.openejb.SystemException(se);
                    }catch(javax.transaction.InvalidTransactionException ite){
                        // do nothing. The validity of the client's transaction is not material to 
                        // processing this exception.
                    }
                    // client recieves a RemoteException; Proxy is invalidated if its a StatefulBean
                }
                systemExceptionPolicy( throwable );
            }
            else{
                throw new ApplicationException(throwable);
            }
                    
        }
        /**
        * The EJB 2.0 policies for container managed transactions depend on the scope of the transaction.
        * This switch-case determins the policy depending on the tx attribute.
        * noTxPolicy( ) for TX_NEVER, TX_NOT_SUPPORTED, and TX_SUPPORTS (when no tx)
        * clientIntiatedTxPolicy() for TX_SUPPORTS (when tx), TX_MANDITORY and TX_REQUIRED (when client tx)
        * containerIntiatedTxPolicy() for TX_REQUIRED (when container tx), TX_REQUIRES_NEW
        *
        * Each of these methods throws an exception, as normal processing, which is propagated by the container
        * to the server.
        */
        switch(deployInfo.getTransactionAttribute(method)){
            case DeploymentInfo.TX_NEVER :
            case DeploymentInfo.TX_NOT_SUPPORTED :
                noTxPolicy(threadContext, bean, throwable, isSystemException);
            case DeploymentInfo.TX_SUPPORTS :
                if(originalTx != null)
                    clientIntiatedTxPolicy(threadContext, bean,originalTx, throwable, isSystemException);
                else{
                    noTxPolicy(threadContext, bean, throwable, isSystemException);
                }
            case  DeploymentInfo.TX_MANDITORY :
                   clientIntiatedTxPolicy(threadContext, bean,originalTx, throwable, isSystemException);
            case DeploymentInfo.TX_REQUIRED :
                if(originalTx != null && originalTx.equals(currentTx))
                   clientIntiatedTxPolicy(threadContext, bean, originalTx, throwable, isSystemException);
                else
                   containerIntiatedTxPolicy(threadContext, bean, originalTx, currentTx, throwable, isSystemException);
            case DeploymentInfo.TX_REQUIRES_NEW :// new tx started with method
                containerIntiatedTxPolicy(threadContext, bean, originalTx, currentTx, throwable, isSystemException);
        }
        
    }
    /**
    * The EJB 2.0 policies for container managed transactions for Unspecified 
    * transaction context (no transaction). TX_NEVER, TX_NOT_SUPPORTED, TX_SUPPORTS (when no tx)
    * For application exceptions simply propagate the exception.
    * For system exceptions discard instance and throw remote exception to the client.
    */
    protected void noTxPolicy(ThreadContext threadContext, EnterpriseBean bean, Throwable throwable, boolean isSystemException)
    throws ApplicationException, InvalidateReferenceException, org.openejb.SystemException{
        if(isSystemException){
            discardBeanInstance(bean, threadContext);
            // client recieves a RemoteException; Proxy is invalidated if its a StatefulBean
            // FIX ME:  This cases the original message to be lost forever.
           systemExceptionPolicy( new RemoteException(throwable.getMessage()));
        }else
            throw new ApplicationException(throwable);
    }
    /*
    * The EJB 2.0 policies for Container initiated transaction.
    * The bean method runs in the context of a transaction that the container started immediately
    * before dispatching the method to the bean. TX_REQUIRED, TX_REQUIRES_NEW
    * If a system exception occurs the container must discard the instance, rollback the transaction, and 
    * throw a RemoteException to the client. The clients tx is not marked for rollback.
    * If an application exception occurs the container must rollback the transaction if the bean 
    * called setRollbackOnly() then it must attempt to rollback the transaciton otherwise. If the transaction was
    * not marked for rollback, the container must attempt to commit the transaction.
    */
    protected void containerIntiatedTxPolicy(ThreadContext threadContext, EnterpriseBean bean, Transaction clientTx, Transaction containerTx, Throwable throwable, boolean isSystemException)
    throws ApplicationException, org.openejb.SystemException, InvalidateReferenceException{
        try{
        if(isSystemException){
            discardBeanInstance(bean, threadContext);
            if(containerTx!=null)
                containerTx.rollback();
            // client recieves a RemoteException; Proxy is invalidated if its a StatefulBean
            systemExceptionPolicy( new RemoteException( "System Exception thrown in bean " + bean + " : " + throwable.toString() ) );
        }else{
            if(containerTx!=null){
            try{
                if(containerTx.getStatus() == Status.STATUS_MARKED_ROLLBACK){
                        containerTx.rollback();
                }else{
                        containerTx.commit();
                }
            }catch(javax.transaction.RollbackException e){
                // do nothing. The container is required to attempt to rollback or commit the 
                // transaction. A RollbackException failure is tolerable.
            }catch(javax.transaction.HeuristicMixedException e){
                // do nothing. A HeuristicMixedException failure is unlikely, but tolerable.
            }catch(javax.transaction.HeuristicRollbackException e){
                // do nothing. A HeuristicMixedException failure is unlikely, but tolerable.
            }
            }
            throw new ApplicationException(throwable);
        }
        }catch(javax.transaction.SystemException se){
            throw new org.openejb.SystemException(se);
        }finally{
            try{
                if(clientTx!=null) 
                    getTxMngr().resume(clientTx);
            }catch(Exception e){
                throw new org.openejb.SystemException(e);
            }
        }
        
    }
    /**
    * The EJB 2.0 policies for client intiated transactions.  TX_SUPPORTS, TX_MANDITORY, TX_REQUIRED
    * The bean runs in the context of the caller's transaction.
    * For application exceptions simply propagate the exception, even if EJBContext.setRollbackOnly() was invoked by the bean.
    * For system exceptions discard instance, mark the transaction for rollback, and throw a TransactionRollBackException.
    */
    protected void clientIntiatedTxPolicy(ThreadContext threadContext, EnterpriseBean bean, Transaction tx, Throwable throwable, boolean isSystemException)
    throws ApplicationException, InvalidateReferenceException, org.openejb.SystemException{
        if(isSystemException){
            discardBeanInstance(bean, threadContext);
            try{
                if(tx!=null)
                    tx.setRollbackOnly();
            }catch(javax.transaction.SystemException se){
                throw new org.openejb.SystemException(se);
            }
            // client recieves a TransactionRolledbackException; Proxy is invalidated if its a StatefulBean
            systemExceptionPolicy(new TransactionRolledbackException(throwable.getMessage()));
        }else
            throw new ApplicationException(throwable);
    }
    /*
    * For Entity and Statless beans:
    * In the advent that the bean throws a system exception the container will 
    * throw a RemoteException wrapped in an ApplicationException
    *
    * For Stateful beans this method is overridden in the StatefulTrasactionScopeHandler.
    * In the advent that the bean throws a system exception the container will 
    * throw the exceptionToReport (TransactionRollbackException or RemoteException) 
    * wrapped in a InvalidateReferenceException.
    */
    protected void systemExceptionPolicy( Throwable exceptionToReport) throws InvalidateReferenceException, ApplicationException{
        // the exception is reported to the client as a exceptionToReport (either a RemoteException or TransactionRollBackException. )
        // The proxy remains valid
        throw new ApplicationException(exceptionToReport);
    }
    /*
    * This method must be implemented by the subsclass so that the bean instance is removed from the
    * container system and left for garbage collection; it must not be reused after its been discarded.
    */
    protected abstract void discardBeanInstance(EnterpriseBean bean, ThreadContext threadContext)
    throws org.openejb.SystemException;
    
    protected abstract void afterBeginBMT(Transaction currentTx, ThreadContext threadContext)
    throws org.openejb.SystemException, org.openejb.ApplicationException;
    
}
