/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: JndiEncArtifact.java,v 1.1 2001/04/05 11:47:38 rmonson Exp $
 */

package org.openejb.core.ivm.naming;
import org.openejb.core.ThreadContext;
import org.openejb.core.DeploymentInfo;
/*
  This class is used as a replacement when a IvmContext referenced by a stateful bean 
  is being serialized for passivation along with the bean.  It ensures that the entire
  JNDI ENC graph is not serialized with the bean and returns a reference to the correct
  IvmContext when its deserialized.
  
  Stateful beans are activated by a thread with the relavent DeploymentInfo object in the 
  ThreadContext which makes it possible to lookup the correct IvmContext and swap in place of 
  this object.
*/
public class JndiEncArtifact implements java.io.Serializable {
    String path = new String();

    public JndiEncArtifact(IvmContext context){
        NameNode node = context.mynode;
        do{
           path = node.atomicName+"/"+path;
           node = node.parent;
        }while(node!=null);
    }
    public Object readResolve() throws java.io.ObjectStreamException{
        ThreadContext thrdCntx = ThreadContext.getThreadContext();
        DeploymentInfo deployment = thrdCntx.getDeploymentInfo();
        javax.naming.Context cntx = deployment.getJndiEnc();
        try{
            Object obj = cntx.lookup(path);
            if(obj==null)
                throw new java.io.InvalidObjectException("JNDI ENC context reference could not be properly resolved when bean instance was activated");
            return obj;
        }catch(javax.naming.NamingException e){
            throw new java.io.InvalidObjectException("JNDI ENC context reference could not be properly resolved due to a JNDI exception, when bean instance was activated");
        }
    }
    
    
}