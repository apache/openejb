/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: Messages.java,v 1.4 2000/09/25 17:41:47 blevins Exp $
 */
package org.openejb.util.resources;

import java.util.ListResourceBundle;

public class Messages extends ListResourceBundle{

 	/*
 	 * Error code prefixes:
 	 *
 	 * as   = Assembler
 	 * cc   = Container
 	 * cm   = ContainerManager
 	 * cs   = ContainerSystem
 	 * di   = DeploymentInfo
 	 * ge   = General Exception
 	 * im   = InstanceManager
 	 * ps   = PassivationStrategy
	 * sa   = Server adapter
	 * se   = Serializer
 	 * ss   = SecurityService
 	 * ts   = TransactionService
	 */

 	static final Object[][] contents = {
 	// LOCALIZE THIS
 		{"ge0001", "FATAL ERROR: Unknown error in {0}.  Please send the following stack trace and this message to openejb-bugs@exolab.org :\n {1}"},
 		{"ge0002", "The required properties object needed by {0} is null ."},// param 0 is the part of the system that needs the Properties object.
 		{"ge0003", "Properties file {0} for {1} not found."}, //param 0 is the properties file name, param 1 is the part of the system that needs the properties file.
 		{"ge0004", "Environment entry {0} not found in {1}."}, //param 0 is the property name, param 1 is the properties file name.
 		{"ge0005", "Environment entry {0} contains illegal value {1}."}, //param 0 is the property name, param 1 is the illegal value.
 		{"ge0006", "Environment entry {0} contains illegal value {1}. {2}"}, //param 0 is the property name, param 1 is the illegal value, param 2 is an additional message.
 		{"ge0007", "The {0} cannot find and load the class {1}."}, //param 0 is the part of the system that needs the class, param 1 is the class that cannot be found.
 		{"ge0008", "The {0} cannot instaniate the class {1}, the class or initializer is not accessible."},//param 0 is the part of the system that needs the class, param 1 is the class that cannot be accessed.
 		{"ge0009", "The {0} cannot instaniate the class {1}, the class may be abstract or an interface."},//param 0 is the part of the system that needs the class, param 1 is the class that cannot be accessed.
 		{"as0001", "FATAL ERROR: Error in XML configuration file.  Received {0} from the parser stating {1} at line {2} column {3}."},// param 0 type of error, param 1 error message from parser, param 2 line number, param 3 column number.
 		{"sa0001", "{0}: Connection to reset by peer."},//param 0 is the name of the server adapter.

 	// END OF MATERIAL TO LOCALIZE
 	};

 	public Object[][] getContents() {
 		return contents;
 	} 
}
