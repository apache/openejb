/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 * 
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 * 
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 * 
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 * 
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 * 
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 * 
 * $Id: JmsQueueInstanceBuilder.java,v 1.4 2000/12/27 05:27:46 dmassey Exp $
 */

package org.openejb.core.jms;

import javax.ejb.MessageDrivenBean;
import javax.jms.ConnectionConsumer;
import javax.jms.JMSException;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.Context;
import org.openejb.DeploymentInfo;
import org.openejb.OpenEJBException;
import org.openejb.SystemException;
import org.openejb.core.jms.asf.JmsServerSession;
import org.openejb.core.jms.asf.JmsServerSessionPool;


/**
 * Responsible for creating an instance, <code>Session</code> and
 * <code>JmsServerSession</code> group.
 */

public class JmsQueueInstanceBuilder extends JmsInstanceBuilder {
    
    /** true if this Queue supports transactions */
    boolean     transacted;
    
	/** the ConnectionConsumer for the deployment */
    ConnectionConsumer consumer;
    
    /** the JmsServerSessionPool for which to build instances */
    JmsServerSessionPool pool;
    
    /** the Queue identity */
    Queue queue;

    /** QueueConnectionFactory used by this builder to create the ASF instances */
    QueueConnectionFactory factory;
    
    /** QueueConnection used to generate the Sessions */
    QueueConnection connection;
    
	/******************************************************************
                        CONSTRUCTOR METHODS
    *******************************************************************/
    public JmsQueueInstanceBuilder(JmsDeploymentInfo deployment, JmsServerSessionPool pool)
    throws SystemException {
        this.deployment = deployment;
        this.pool = pool;
        
        if (deployment.getTransactionAttribute() == DeploymentInfo.TX_NOT_SUPPORTED) {
            transacted = false;
        } else {
            transacted = true;
        }
        
        // Prepares the required provider resources using the factory identified in the Deployment Descriptor
        // Of most importance are the Connection and the ConnectionConsumer
        factory = (QueueConnectionFactory) lookup("QueueConnectionFactory");
        try {
            connection = factory.createQueueConnection();  
            queue = (Queue) lookup(deployment.getDestination());
            consumer = connection.createConnectionConsumer(queue, deployment.getMessageSelector(), pool, 5); // MAGIC NUMBER - use env-entry?
        } catch (JMSException e) {
            try {
            if (connection != null) {
                connection.close();
            }
            } catch (JMSException ex) {
                // does nothing
            } finally {
                throw new SystemException("Could not create ConnectionConsumer \""+deployment.getDestination()+"\" jms container failed",e);
            }
        }
	}
	
	/**
	 * Creates the ASF instance framework for each Message-Driven Bean instance.
     *
     * @return  the new JmsServerSession instance
	 */
	public JmsServerSession buildServerSession()
    throws OpenEJBException, SystemException {
        MessageDrivenBean mBean;
        Session instanceSession;
        // Creates the new Message-Driven Bean instance and passes it to a new JmsMessageListenerProxy
        try {
            mBean = (MessageDrivenBean) deployment.getBeanClass().newInstance();
        } catch (Exception e) {
            throw new OpenEJBException("Can't instantiate \""+deployment.getBeanClass()+"\" jms container failed",e);
        }
        JmsContextProxy proxy = new JmsContextProxy(mBean, deployment);
        
        // Creates a single QueueSession instance from the QueueConnnection and 
        // sets its MessageListener to be the proxy
        try {
            instanceSession = connection.createQueueSession(transacted, deployment.getAcknowledgeMode());
            instanceSession.setMessageListener((MessageListener) proxy);
        } catch (JMSException e) {
            throw new SystemException("Could not create Session for \""+deployment.getDestination()+"\" jms container failed",e);
        }                
		
        // Creates a new JmsServerSession, passing it the new QueueSession
        return new JmsServerSession(instanceSession, pool, proxy);
	}
	
    /** 
     * Starts the Connection. Begins message delivery.
     */
    public void startReceiving()
    throws OpenEJBException {
        try {
            connection.start();
        } catch (JMSException e) {
            throw new OpenEJBException("Could not create start Connection for \""+deployment.getDestination()+"\" jms container failed",e);
        }
    }
    
    /**
     * Stops receiving messages and closes the connection.
     */
    public void closeConnection() {
         try {
            connection.stop();
            connection.close();
        } catch (JMSException e) {
            // What should this do? Throw an SystemException?
        }
    }
    
    // Empty
	public void init(DeploymentInfo deploymentInfo) {
	}	
}


