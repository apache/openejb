/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: HashThreadLocal.java,v 1.1 2000/10/21 14:57:01 rmonson Exp $
 */
package org.openejb.util;
import java.util.HashMap;

/**
* This class allows thread-specific storage (TSS) of values by key, so that object are
* stored by thread identity as well as an application specific key.  This makes it possible 
* have context sensitive TSS.
* 
* @author <a href="richard@monson-haefel.com">Richard Monson-Haefel</a>
* @version $ $
* @see org.openejb.core.SharedLocalConnectionManager;
*/

/*
* This variation of ThreadLocal accomplishes thread-specific storage by thread as well
* as by object.  Values are associated with both an key and a thread, which allows 
* each value to stored specific to an object and thread. 
*
* @see org.openejb.resource.SharedLocalConnectionManager
* @author <a href="richard@monson-haefel.com">Richard Monson-Haefel</a>
* @version $ $
*/
public class HashThreadLocal {
    HashMap keyMap = new HashMap();
    public synchronized void put(Object key, Object value){
        FastThreadLocal threadLocal = (FastThreadLocal)keyMap.get(key);
        if(threadLocal==null){
            threadLocal = new FastThreadLocal();
            keyMap.put(key, threadLocal);
        }
        threadLocal.set(value);
    }
    public synchronized Object get(Object key){
        FastThreadLocal threadLocal = (FastThreadLocal)keyMap.get(key);
        if(threadLocal==null)return null;
        return threadLocal.get();
    }
}