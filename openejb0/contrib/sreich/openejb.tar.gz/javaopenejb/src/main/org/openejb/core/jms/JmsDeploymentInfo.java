/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id$
 */


package org.openejb.core.jms;


import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.Name;
import org.openejb.Container;
import org.openejb.core.ContainerSystem;
import org.openejb.OpenEJB;

public class JmsDeploymentInfo extends org.openejb.core.DeploymentInfo{

    /**
     * The constant that will be returned from the <code>getDestinationType</code> 
     * method if this bean will connect to a JMS queue session.
     * @see #getConnectionType
     */
    final public static byte JMS_QUEUE = (byte)11;
	
    /**
     * The constant that will be returned from the <code>getDestinationType</code> 
     * method if this bean will connect to a JMS topic session.
     * @see #getConnectionType
     */
    final public static byte JMS_TOPIC = (byte)12;
	
    /**
     * The constant that will be returned from the <code>getDestinationType</code> 
     * method if this bean will connect to a JMS durable topic session.
     * @see #getConnectionType
     */
    final public static byte JMS_DURABLE_TOPIC = (byte)13;
	
	
    private Object deploymentId;
    private Container container;
    private Class beanClass;
    private byte destinationType;
    private String destination;
    private String messageSelector = null;
    private int ackMode = Session.AUTO_ACKNOWLEDGE;
    private boolean beanManagedTransaction = false;
    private byte transactionAttribute = TX_NOT_SUPPORTED;
    private boolean useCallerIdentity = true;
    private String runAsRole = null;
    private Context jndiContextRoot;
    
    /**
     * Can be one of the following DeploymentInfo values: STATEFUL, STATELESS, BMP_ENTITY, CMP_ENTITY, MESSAGE_DRIVEN.
     */
    private byte componentType;
	
    
    /**
     * Creates an empty JmsDeploymentInfo instance.
     */
    public JmsDeploymentInfo( ){}
    
    /**
     * Constructs a DeploymentInfo object to represent the specified bean's deployment information.
     *
     * @param cs the ContainerSystem the bean belongs to
     * @param did the id of this bean deployment 
     * @param cid the id of the Container this bean deployment is in
     * @param cmid the id of the ContainerManager this bean's Container is in
     * @param beanClassName the fully qualified class name of the bean's class definition
     * @param componentType one of the component type constants defined in org.openejb.DeploymentInfo
     * @param destType one of the connection types defined in org.openejb.core.jms.JmsDeploymentInfo
     * @param destName the name of the JMS connection the bean will service
     * @throws ClassNotFoundException if the bean class definition could not be found and loaded
     * @see org.openejb.ContainerSystem
     * @see org.openejb.Container#getContainerID
     * @see org.openejb.ContainerManager#getContainerManagerID
     * @see org.openejb.DeploymentInfo#MESSAGE_DRIVEN
     */
    public JmsDeploymentInfo(Object did, String beanClassName, 
                             byte componentType, byte destType, String dest) 
    throws org.openejb.SystemException{

        try{
            set(did, Class.forName(beanClassName), componentType, destType, dest);
        }catch(java.lang.ClassNotFoundException cnfe){
            throw new org.openejb.SystemException(cnfe);
        }
    }
    
    /**
     * Constructs a DeploymentInfo object to represent the specified bean's deployment information.
     *
     * @param cs the ContainerSystem the bean belongs to
     * @param did the id of this bean deployment 
     * @param cid the id of the Container this bean deployment is in
     * @param cmid the id of the ContainerManager this bean's Container is in
     * @param bean the fully qualified class name of the bean's class definition
     * @param componentType one of the component type constants defined in org.openejb.DeploymentInfo
     * @param destType one of the connection types defined in org.openejb.core.jms.JmsDeploymentInfo
     * @param dest the name of the JMS connection the bean will service
     * @see org.openejb.ContainerSystem
     * @see org.openejb.Container#getContainerID
     * @see org.openejb.ContainerManager#getContainerManagerID
     * @see org.openejb.DeploymentInfo#MESSAGE_DRIVEN
     */
    public void set(Object did, Class bean,
					byte componentType, byte destType, String dest)
    throws org.openejb.SystemException{
                            
        deploymentId = did;

        beanClass = bean;
        this.componentType = componentType;
		destinationType = destType;
		destination = dest;
	}
    
    
    //====================================
    // begin DeploymentInfo Implementation
    //

    /**
     * Gets the type of this bean component.
     * Will return a <code>STATEFUL</code>, <code>STATELESS</code>, <code>BMP_ENTITY</code> or <code>CMP_ENTITY</code>.
     *
     * @param        
     * @return Returns <code>STATEFUL</code>, <code>STATELESS</code>, <code>BMP_ENTITY</code> or <code>CMP_ENTITY</code>.
     * @see #STATEFUL
     * @see #STATELESS
     * @see #BMP_ENTITY
     * @see #CMP_ENTITY
     * @see #MESSAGE_DRIVEN
     */
    public byte getComponentType( ){
        return componentType;
    }
    
    /**
	 * NOT USED IN JMS DEPLOYMENT
	 *
     * Gets the transaction attribute that must be applied to this method when executing.
     *
     * The type can be anyone of <code>TX_NEVER</code>, <code>TX_NOT_SUPPORTED</code>, <code>TX_SUPPORTS</code>, <code>TX_MANDITORY</code>, <code>TX_REQUIRED</code>, <code>TX_REQUIRES_NEW</code>, 
     *
     * @param method the bean's method for which transaction attribute information is needed
     * @return the transaction constant that states the method's transaction attribute   
     */
    public byte getTransactionAttribute(Method method){
        return TX_NOT_SUPPORTED;
    }

    /**
	 * NOT USE IN JMS DEPLOYMENT
	 *
     * Gets the roles that are authorised to execute this method.
     *
     * Used primarily by the container to check the caller's rights to 
     * access and execute the specifed method.
     *
     * @param method the bean's method for which security information is needed
     * @return a String array of the roles that are authorised to execute this method
     * @see org.openejb.spi.SecurityService#isCallerAuthorized
     */
    public String [] getAuthorizedRoles(Method method){
        return null;
    }

    public String [] getAuthorizedRoles(String action){
        return null;
    }

    /**
     * Gets the the container that this deployed bean is in.
     *
     * @return the deployment's container.
     * @see Container#getContainerID() Container.getContainerID()
     */
    public org.openejb.Container getContainer( ){
        return container;
    }
    
    /**
    * Container must have its Container set explicitly by the Assembler to avoid
    * a chicken and egg problem: Which is created first the container or the DeploymentInfo
    * This assembler will invoke this method when needed. The Container must be set before
    * the bean is ready to process requests.
    */
    public void setContainer(Container cont){
        container = cont;
    }


    /**
     * Gets the id of this bean deployment.
     *
     * @return the id of of this bean deployment
     * @see ContainerManager#getContainerManagerID() ContainerManager.getContainerManagerID()
     * @see Container#getContainerManagerID() Container.getContainerManagerID()
     */
    public Object getDeploymentID( ){
        return deploymentId;
    }

    /**
     * Returns true if this bean deployment has chosen  bean-managed transaction demarcation.
     * Returns false if the continer will be managing the bean's transactions.
     *
     * @return Returns true if this bean deployment is managing its own transactions.
     */
    public boolean isBeanManagedTransaction(){
        return beanManagedTransaction;
    }

    /**
	 * NOT USE IN JMS DEPLOYMENT
	 *
     * Gets the home interface for the bean deployment. 
     *
     * Used primarily by Servers integrating OpenEJB into their platform.  Aids in implementing
     * the bean's home interface.
     *
     * @param        
     * @return a Class object of the bean's home interface
     * @see javax.ejb.EJBHome
     */
    public Class getHomeInterface( ){
        return null;
    }

    /**
	 * NOT USE IN JMS DEPLOYMENT
	 *
     * Gets the remote interface for the bean deployment. 
     *
     * Used primarily by Servers integrating OpenEJB into their platform.  Aids in implementing
     * the bean's remote interface.
     *
     * @return a Class object of the bean's remote interface
     * @see javax.ejb.EJBObject
     */
    public Class getRemoteInterface( ){
        return null;
    }

    /**
     * Gets the bean's class definition.
     *
     * Used primarily by containers to instantiate new instances of a bean.
     * 
     * @return a Class object of the bean's class definition
     * @see javax.ejb.EnterpriseBean
     */
    public Class getBeanClass( ){
        return beanClass;
    }

    /**
	 * NOT USE IN JMS DEPLOYMENT
	 *
     * Gets the Class type of the primary key for this bean deployment.
     * Returns null if the bean is a type that does not need a primary key.
     * 
     * @return the Class type of the bean's primary key or null if the bean doesn't need a primary key
     */
    public Class getPrimaryKeyClass( ){
        return null;
    }
	
    //
    // end DeploymentInfo Implementation
    //==================================


    //===================================================
    // begin accessors & mutators for this implementation
    //
	
	/**
	 * Gets the destination type used by this deployment of the MessageDrivenBean.
	 *
	 * @return the connection type
	 * @see #JMS_QUEUE
	 * @see #JMS_TOPIC
	 * @see #JMS_DURABLE_TOPIC
	 */
	public byte getDestinationType( ){
		return destinationType;
	}
	
	/**
	 * Gets the name of the JMS connection the bean should service.
	 *
	 * @return the fully qualified name of the JMS connection
	 */
	public String getDestination( ){
		return destination;
	}
	
	/**
	 * Sets the JMS message selector used to filter messages for the bean.
	 *
	 * @param msgSelector the string containing the JMS message selector
	 */
	public void setMessageSelector(String msgSelector){
		messageSelector = msgSelector;
	}
	
	/**
	 * Gets the JMS message selector used by the bean to filter messages
	 *
	 * @return the JMS message selector String
	 */
	public String getMessageSelector( ){
		return messageSelector;
	}
	
	/**
	 * Sets the message acknowledgement mode for the bean as defined in javax.jms.Session
	 *
	 * @param mode AUTO_ACKNOWLEDGE or DUPS_OK_ACKNOWLEDGE
	 */
	public void setAcknowledgeMode(int mode){
		ackMode = mode;
	}
	
	/**
	 * Gets the message acknowledgement mode for the bean as defined in javax.jms.Session
	 *
	 * @return AUTO_ACKNOWLEDGE or DUPS_OK_ACKNOWLEDGE
	 */
	public int getAcknowledgeMode( ){
		return ackMode;
	}

	/** 
	 * Sets the transaction attribute for this bean 
	 *
	 * @param txAttr one of the two supported transaction attributes
	 * @see #TX_NOT_SUPPORTED    
     * @see #TX_REQUIRED
	 */
	public void setTransactionAttribute(byte txAttr){
		transactionAttribute = txAttr;
	}
	
	/**
	 * Gets the transaction attribute for this bean
	 *
	 * @param one of the two supported transaction attributes
	 * @see #TX_NOT_SUPPORTED    
     * @see #TX_REQUIRED
	 */
	public byte getTransactionAttribute( ){
		return transactionAttribute;
	}
	
	/**
	 * Sets the caller identity attribute. If false, the bean uses the
	 * runAsRole identity.
	 *
	 * @param useCallerId specify true to use the message authors security id
	 */
	public void setUseCallerIdentity(boolean useCallerId){
		useCallerIdentity = useCallerId;
	}
	
	/**
	 * Gets the caller identity attribute
	 *
	 * @return true if the bean is using the caller's identity, false if
	 *			the bean is using the runAsRole identity
	 */
	public boolean isUseCallerIdentity( ){
		return useCallerIdentity;
	}
	
	
	/**
	 * Sets the role to use if the bean is not using the caller identity
	 *
	 * @param role NMTOKEN compliant security role
	 */
	public void setRunAsRole(String role){
		runAsRole = role;
	}
	
	/**
	 * Gets the role the bean is running under
	 *
	 * @return the role, may be null
	 */
	public String getRunAsRole( ){
		return runAsRole;
	}
	
    /**
     * Sets this bean deployment to container-managed or bean-managed transaction demarcation.
     * 
     * @param value true if this bean is managing transaction, false if the container should manage them
     */
    public void setBeanManagedTransaction(boolean value){
        beanManagedTransaction = value;
    }

    /**
     * Sets the JNDI namespace for the bean's environment.  This will be the ony 
     * namespace that the bean will be able to access using the java: URL in the JNDI.
     * 
     * @param the Context of the bean's JNDI environment
     * @see javax.naming.Context
     */
    public void setJndiEnc(javax.naming.Context cntx){
        jndiContextRoot = cntx;
    }

    /**
     * Gets the JNDI namespace for the bean's environment.  This will be the ony 
     * namespace that the bean will be able to access using the java: URL in the JNDI.
     * 
     * Used primarily by the IntraVM naming server to get a bean's environment naming context 
     * when the bean performs a lookup using the "java:" URL.
     * @see javax.naming.Context
     */
    public Context getJndiEnc( ){
        return jndiContextRoot;
    }
    
    //
    // end accessors & mutators for this implementation
    //=================================================

    //====================================
    // Begin JmsDeploymentInfo Initialization
    //
    
    
    //
    // End JmsDeploymentInfo Initialization
    //==================================
}
