/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 * 
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 * 
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 * 
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 * 
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 * 
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 * 
 * $Id: JmsConnectionBuilder.java,v 1.6 2000/12/27 05:27:46 dmassey Exp $
 */

package org.openejb.core.jms;


import java.util.Properties;
import javax.jms.ConnectionConsumer;
import org.openejb.DeploymentInfo;
import org.openejb.OpenEJBException;
import org.openejb.SystemException;
import org.openejb.core.jms.asf.JmsServerSession;
import org.openejb.core.jms.asf.JmsServerSessionPool;


/**
 * Establishes the JMS ASF structure for a single Message-Driven
 * Bean container.
 *
 * @author Dan Massey
 * @version 0.1, 10/09/2000
 * @see org.openejb.core.jms.JmsContainer
 * @see org.openejb.core.jms.JmsServerSessionPool
 * @see org.openejb.core.jms.JmsServerSession
 * @see javax.jms.ConnectionConsumer
 * @since JDK 1.2
 */

public class JmsConnectionBuilder {
	
    
    /** the {@link JmsContainer} holding the deployments */
    JmsContainer jmsContainer;
	
    /** properties provided by the container */
    Properties properties;

    
    /******************************************************************
                        CONSTRUCTOR METHODS
    *******************************************************************/
    public JmsConnectionBuilder(){
    }
	
    
    //============================================
    // begin methods unique to this implementation
    //
    
    /**
     * Provides the <code>JmsConnectionBuilder</code> with the information
     * necessary to construct the <code>JmsServerSessionPools</code>.
     *
     * @param   container   the parent <code>JmsContainer</code> 
     * @param   properties  the openEJB system properties
     * @see org.openejb.core.jms.JmsContainer
     */
	public void init(JmsContainer container, Properties properties){
        jmsContainer = container;
	    this.properties = properties;
    }
	
    /**
     * Creates the JMS ASF infrastructure for each <code>DeploymentInfo</code> in the 
     * {@link JmsContainer}. The call to initialize each pool also begins
     * message delivery to that Message-Driven Bean.
     *
     * @return  the array of {@link JmsServerSessionPool}s
     */
    public JmsServerSessionPool[] build()
    throws OpenEJBException, SystemException {
        JmsDeploymentInfo[]	    deployments;
        JmsServerSessionPool	pool;
        JmsServerSessionPool[]	pools;

        // Builds a JmsServerSession for each DeploymentInfo
        deployments = jmsContainer.getJmsDeployments();
        pools = new JmsServerSessionPool[deployments.length];
        for (int i = 0; i < deployments.length; i++) {
            pool = new JmsServerSessionPool();
            
            // Builds and starts each Bean deployment
            pool.init(jmsContainer, deployments[i], properties);
            pools[i] = pool;
        }		
        return pools;
    }
    
    //
    // end methods unique to this implementation
    //================================================
	
}