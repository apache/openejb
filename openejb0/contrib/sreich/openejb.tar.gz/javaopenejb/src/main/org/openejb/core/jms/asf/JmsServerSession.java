/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: JmsServerSession.java,v 1.4 2000/12/27 05:28:14 dmassey Exp $
 */

package org.openejb.core.jms.asf;


import javax.jms.JMSException;
import javax.jms.ServerSession;
import javax.jms.Session;
import org.openejb.SystemException;
import org.openejb.core.jms.JmsContextProxy;


/**
 * <code>JmsServerSessions</code> associate a JMS <code>Session</code> from the 
 * JMS provider with a thread required to process incoming messages. 
 */

public class JmsServerSession implements ServerSession {
	
    /** if true, the instance should be discarded */
    boolean discard = false;
    
    /** provider <code>Session</code> */
    Session session;

    /** used to remove the Message-Driven Bean on destruction of the JmsServerSession */
    JmsContextProxy proxy;
    
    /** pool managing this <code>JmsServerSession</code> */
    JmsServerSessionPool pool;		
    
    /******************************************************************
                    CONSTRUCTOR METHODS
    *******************************************************************/
    public JmsServerSession(Session providerSession, JmsServerSessionPool serverSessionPool, JmsContextProxy beanProxy){
        session = providerSession;
        pool = serverSessionPool;
        proxy = beanProxy;
        proxy.setServerSession(this);
    }
	
    //===============================
    // begin ServerSession Implementation
    //
	
    /**
     * Simple session accessor.
     */
    public Session getSession() {
        return session;
    }

    /**
     * Calls the provider <code>Session</code> run method to process incoming
     * messages. Performs housekeeping and returns this <code>JmsServerSession</code>
     * to the pool.
     */
    public void start() {
        RunSession runner = new RunSession(this, session, pool);
        Thread t = new Thread(runner);
        t.start();
    }

    //
    // end ServerSession Implementation
    //===============================
    
    //===============================
    // begin methods unique to this implementation
    //
    
    /**
     * Sets a flag to keep the <code>RunSession</code> from returning the 
     * <code>JmsServerSession</code> to the {@link JmsServerSessionPool}, then
     * frees the other resources associated with the instance.
     */
    public void discard() {
        discard = true;
        free();
    }
    
    /**
     * Deconstructs the JmsServerSession and its supporting classes.
     */
    public void free() {
        // Cleanup Session and bean (through proxy)
        try {
            session.close();
        } catch (JMSException e) {
            // throw new SystemException("Could not close JMS session \""+session+"\" jms container failed",e);
            // What should this do?
        }
        proxy.remove();
    }
    
    /**
     * Runs the Session, then returns the JmsServerSession to
     * the JmsServerSessionPool.
     */
    class RunSession implements Runnable {
        JmsServerSession        serverSession;
        JmsServerSessionPool    pool;
        Session                 session;
       
        public RunSession(JmsServerSession serverSession, Session session, JmsServerSessionPool pool) {
            this.serverSession = serverSession;
            this.session = session;
            this.pool = pool;
        }
        
        public void run() {
            if (session != null) {
                session.run();
            }
            
            // Check for discard flag before returning
            if (!discard) {
                pool.returnServerSession(serverSession);
            }
        }
    }
    
    //
    // end methods unique to this implementation
    //===============================
}