/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 * 
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 * 
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 * 
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 * 
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 * 
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 * 
 * $Id: JmsTopicInstanceBuilder.java,v 1.4 2000/12/27 05:27:46 dmassey Exp $
 */

package org.openejb.core.jms;

import javax.ejb.MessageDrivenBean;
import javax.jms.ConnectionConsumer;
import javax.jms.JMSException;
import javax.jms.MessageListener;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSession;
import javax.jms.Session;
import javax.naming.Context;
import org.openejb.DeploymentInfo;
import org.openejb.OpenEJBException;
import org.openejb.SystemException;
import org.openejb.core.jms.asf.JmsServerSession;
import org.openejb.core.jms.asf.JmsServerSessionPool;


/**
 * Responsible for creating an instance, <code>Session</code> and
 * <code>JmsServerSession</code> group.
 */

public class JmsTopicInstanceBuilder extends JmsInstanceBuilder {
    
    /** true if this Topic supports transactions */
    boolean     transacted;
    
	/** the ConnectionConsumer for the deployment */
    ConnectionConsumer consumer;
    
    /** the JmsServerSessionPool for which to build instances */
    JmsServerSessionPool pool;
    
    /** the Topic identity */
    Topic topic;

    /** TopicConnectionFactory used by this builder to create the ASF instances */
    TopicConnectionFactory factory;
    
    /** TopicConnection used to generate the Sessions */
    TopicConnection connection;
    
	/******************************************************************
                        CONSTRUCTOR METHODS
    *******************************************************************/
    public JmsTopicInstanceBuilder(JmsDeploymentInfo deployment, JmsServerSessionPool pool)
    throws SystemException {
        this.deployment = deployment;
        this.pool = pool;
        
        if (deployment.getTransactionAttribute() == DeploymentInfo.TX_NOT_SUPPORTED) {
            transacted = false;
        } else {
            transacted = true;
        }
        
        // Prepares the required provider resources using the factory identified in the Deployment Descriptor
        // Of most importance are the Connection and the ConnectionConsumer
        factory = (TopicConnectionFactory) lookup("TopicConnectionFactory");
        try {
            connection = factory.createTopicConnection();
            topic =  (Topic) lookup(deployment.getDestination());
            
            // Creates a durable topic subscription if required
            if (deployment.getDestinationType() == JmsDeploymentInfo.JMS_DURABLE_TOPIC) {
                consumer = connection.createDurableConnectionConsumer(topic, 
                        deployment.getBeanClass().toString() + ":" + deployment.getDestination() + ":" + deployment.getMessageSelector(),
                        deployment.getMessageSelector(), pool, 5); // MAGIC NUMBER - use env-entry?
            } else {
                consumer = connection.createConnectionConsumer(topic, deployment.getMessageSelector(), pool, 5); // MAGIC NUMBER - use env-entry?
            }
        } catch (JMSException e) {
            try {
            if (connection != null) {
                connection.close();
            }
            } catch (JMSException ex) {
                // does nothing
            } finally {
                throw new SystemException("Could not create ConnectionConsumer \""+deployment.getDestination()+"\" jms container failed",e);
            }
        } 
	}
	
	/**
	 * Creates the ASF instance framework for each Message-Driven Bean instance.
     *
     * @return  the new JmsServerSession instance
	 */
	public JmsServerSession buildServerSession()
    throws OpenEJBException, SystemException {
        MessageDrivenBean mBean;
        Session instanceSession;
        
        // Creates the new Message-Driven Bean instance and passes it to a new JmsMessageListenerProxy
        try {
            mBean = (MessageDrivenBean) deployment.getBeanClass().newInstance();
        } catch (Exception e) {
            throw new OpenEJBException("Can't instantiate \""+deployment.getBeanClass()+"\" jms container failed",e);
        }
        JmsContextProxy proxy = new JmsContextProxy(mBean, deployment);
                
        // Creates a single TopicSession instance from the TopicConnnection and 
        // sets its MessageListener to be the proxy
        try {
            instanceSession = connection.createTopicSession(transacted, deployment.getAcknowledgeMode());
            instanceSession.setMessageListener((MessageListener) proxy);
        } catch (JMSException e) {
            throw new SystemException("Could not create Session for \""+deployment.getDestination()+"\" jms container failed",e);
        }
        		
        // Creates a new JmsServerSession, passing it the new TopicSession
        return new JmsServerSession(instanceSession, pool, proxy);
	}
	
    /** 
     * Starts the Connection. Begins message delivery.
     */
    public void startReceiving()
    throws OpenEJBException {
        try {
            connection.start();
        } catch (JMSException e) {
            throw new OpenEJBException("Could not create start Connection for \""+deployment.getDestination()+"\" jms container failed",e);
        }
    }
    
    /**
     * Stops receiving messages and closes the connection.
     */
    public void closeConnection() {
        try {
            connection.stop();
            connection.close();
        } catch (JMSException e) {
            // What should this do? Throw an SystemException?
        }
    }
    
    // Empty
	public void init(DeploymentInfo deploymentInfo) {
	}	
}


