/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 * 
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 * 
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 * 
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 * 
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 * 
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 * 
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 * 
 * $Id: JmsContextProxy.java,v 1.3 2001/02/06 04:29:49 dmassey Exp $
 */

package org.openejb.core.jms;


import java.lang.reflect.Method;
import java.security.Identity;
import java.security.Principal;
import java.util.Properties;
import javax.ejb.EJBHome;
import javax.ejb.MessageDrivenBean;
import javax.ejb.MessageDrivenContext;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Session;
import javax.transaction.Transaction;
import javax.transaction.UserTransaction;
import org.openejb.OpenEJB;
import org.openejb.SystemException;
import org.openejb.core.CoreContext;
import org.openejb.core.CoreUserTransaction;
import org.openejb.core.DeploymentInfo;
import org.openejb.core.Operations;
import org.openejb.core.jms.asf.JmsServerSession;
import javax.jms.XASession;

/**
 * Primary point of interception for a Message-Driven Bean instance. Sits between
 * the JMS Session from the JMS Provider and the bean. Also acts as the 
 * MessageDrivenContext for the bean.
 *
 * This class imposes restrictions on what Message-Driven Bean methods can access which JmsContext
 * methods.  While the CoreContext handles restrictions related to container- vs. bean-managed 
 * transaction beans, this class manages restrictions related to the position of the bean 
 * in its life-cycle to the JmsContext operation being performed.  Restrictions are specified
 * in the EJB specification.  The CoreContext actually fulfills the request, this class just 
 * applies restrictions on access.
 *
 * @author <a href="mailto:dan@danmassey.com">Dan Massey</a>
 * @author <a href="mailto:Richard@Monson-Haefel.com">Richard Monson-Haefel</a>
 */
public class JmsContextProxy implements MessageListener, MessageDrivenContext {
    
       
    /** true if the transaction has been set to RollBackOnly */
    boolean rollBackOnly = false;
    
    /** if true, the bean cannot call context transaction methods */
    private boolean _containerTransaction = true;
    
    /** the JmsContainer that houses the proxy */
    JmsContainer container;

    /** the deployment information for the bean */
    JmsDeploymentInfo deployment;
    
    /** parent JmsServerSession */
    JmsServerSession serverSession;
    
    /** the container's JmsTransactionScopeHandler */
    JmsTransactionScopeHandler txHandle;

    /** the Message-Driven Bean for which this instance is a proxy */   
    MessageDrivenBean messageBean;
    
    /** the alternate MessageListenerReference to the Bean instance */
    MessageListener messageListener;
    
       
    public JmsContextProxy(MessageDrivenBean messageBean, JmsDeploymentInfo deployment)
    throws SystemException {
        this.messageBean = messageBean;
        this.messageListener = (MessageListener) messageBean;
        this.deployment = deployment;
        container = (JmsContainer) deployment.getContainer();
        txHandle = container.getTransactionScopeHandler();
        
        // sets the EJBContext for the Message-Driven Bean
        synchronized (messageBean) {
            messageBean.setMessageDrivenContext(this);
        }

        // invokes the ejbCreate method
        Method createMethod = deployment.getCreateMethod();
        try {
            synchronized (messageBean) {
                createMethod.invoke(messageBean, null);
            }            
        } catch (Exception e) {
            throw new SystemException("Can not create a new instance.", e);
        }
    }
	
    
    //============================================
    // begin MessageListener implementation
    //

    public void onMessage(Message message) {
        XASession xaSession = (XASession)serverSession.getSession();
        try{
        txHandle.beforeInvoke(xaSession, deployment);
        try {
            messageListener.onMessage(message);
        } catch (Exception re) {
            serverSession.discard();
            txHandle.handleSystemException();
        }                
        txHandle.afterInvoke(deployment, message);
        }catch(org.openejb.SystemException se){
        } catch (Exception re) {
            serverSession.discard();
            ;//log exception
        }
	}

    //
    // end MessageListener implementation
    //================================================	
    
    
    //============================================
    // begin MessageDrivenContext implementation
    //
    
    public UserTransaction getUserTransaction()
    throws IllegalStateException {
        if (deployment.isBeanManagedTransaction()) {
            UserTransaction userTransaction = new CoreUserTransaction(OpenEJB.getTransactionManager());
            return userTransaction;
        } else {
            throw new java.lang.IllegalStateException("container-managed transaction beans can not access the UserTransaction");
        }
    }

    public void setRollbackOnly()
    throws IllegalStateException {
        if (deployment.isBeanManagedTransaction()) {
            throw new java.lang.IllegalStateException("can not call method as part of a bean-managed transaction");
        }else{
            try{
                Transaction currentTx = OpenEJB.getTransactionManager().getTransaction();
                if(currentTx!=null){
                    currentTx.setRollbackOnly();
                }
            }catch(javax.transaction.SystemException se){
                throw new RuntimeException("Transaction System Failure");
            }
        }
    }

    public boolean getRollbackOnly()
    throws IllegalStateException {
        if (deployment.isBeanManagedTransaction()) {
            throw new java.lang.IllegalStateException("can not call method as part of a bean-managed transaction");
        }else{
            try{
            int status = OpenEJB.getTransactionManager().getStatus();
            return status == javax.transaction.Status.STATUS_MARKED_ROLLBACK ;
            }catch(javax.transaction.SystemException se){
                throw new RuntimeException("Transaction System Exception");
            }
        }
    }
    
    // ILLEGAL FOR MESSAGE-DRIVEN BEANS TO CALL
    public EJBHome getEJBHome() {
        throw new IllegalStateException("Invalid operation attempted");
	}
    
    public Principal getCallerPrincipal() {
        throw new IllegalStateException("Invalid operation attempted");
    }
   
    public boolean isCallerInRole(String roleName) {
        throw new IllegalStateException("Invalid operation attempted");
    }
    
    // UNSUPPORTED DEPRICATED METHODS
    public boolean isCallerInRole(java.security.Identity role) {
        throw new java.lang.UnsupportedOperationException();
    }
    public java.security.Identity getCallerIdentity() {
        throw new java.lang.UnsupportedOperationException();
    }
    public java.util.Properties getEnvironment() {
        throw new java.lang.UnsupportedOperationException();
    }
    
    //
    // end MessageDrivenContext implementation
    //================================================
    
    
    //================================================
    // begin implementation unique to JmsContextProxy
    //
    
    /**
     * Removes the bean and frees any other resources acquired by the proxy.
     */
    public void remove() {
        messageBean.ejbRemove();
    }
    
    /**
     * Allows the {@link org.openejb.core.jms.asf.JmsServerSession} to pass a
     * reference to the <code>JmsContextProxy</code> for "transition to
     * does not exist state" events.
     *
     * @param serverSession the <code>JmsServerSession</code>
     */
    public void setServerSession(JmsServerSession serverSession) {
        this.serverSession = serverSession;
    }
    
    //
    // end implementation unique to JmsContextProxy
    //================================================
}