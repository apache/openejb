/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: JaasSecurityService.java,v 1.2 2001/02/12 21:52:33 rmonson Exp $
 */
 
package org.openejb.spi.impl;


import java.security.Principal;
import java.security.AccessControlContext;
import java.security.AccessController;
import javax.security.auth.Subject;
import java.util.Properties;
import org.openejb.util.FastThreadLocal;

/**
* This implementation of the SecurityService can be used with any server
* that depends on JAAS for authorization security. The current Subject can
* either be passed to the container explicitly in the securityIdentity of the 
* RpcContainer.invoke( ) method, or a null can be passed and the Subject.doXX( )
* method maybe called.  
*
* If the Subject.doXX( ) method is called then JAAS will maintain the Subject thread
* association and the server must pass a null to the RpcContainer.invoke() securityIdentity
* argument. When the isCallerAuthorized() methods or the translateTo( ) method is called 
* with the null securityIdentity, this object will attempt to obtain the current Subject
* using JAAS Subject.getSubject(AccessControlContext) method, which it will then use as 
* the securityIdentity.
*
* If the Subject is passed explicitly to the RpcContainer.invoke( ) method, then the subject
* will be passed to the isCallerAuthorized() methods or the translateTo( ) method and this 
* object will not attempt to get it from the Subject.getSubject(AccessConytrolContext) method.
*/
public class JaasSecurityService implements org.openejb.spi.SecurityService{
    
    private static FastThreadLocal threadStorage = new FastThreadLocal();
    
    public void init(java.util.Properties props){
        
    }
    
    /**
    * If the securityIdentity is not null this method will attempt to cast it to the 
    * javax.security.auth.Subject type.  If the securityIdentity is null, this method
    * will attempt to get the Subject from the JAAS thread context using Subject.getSubject()
    */
    protected Subject getSubject(Object securityIdentity)
    throws org.openejb.SystemException{
        if(securityIdentity == null){
          AccessControlContext acc = AccessController.getContext();
          Subject subject = Subject.getSubject(acc);   
          if(subject==null)
            throw new org.openejb.SystemException("No security identity is avaible");
          else
            return subject;
        }else if(securityIdentity instanceof Subject){
          return (Subject)securityIdentity;
        }else{
            throw new org.openejb.SystemException("Invalid securityIdentity. Must be of type Subject or null");
        }
    }
    
    
   /**
    * Check if securityIdentity is authorized to perform the specified action. 
    * This is currently used by OpenEJB to check if a caller is authorized to 
    * to assume at least one of a collection of roles, the roles authorized for 
    * a particular method of a particular deployment.
    */   
    public boolean isCallerAuthorized(Object securityIdentity,String [] roleNames){
        try{
        Subject subject = this.getSubject(securityIdentity);
        java.util.Set prncplsSet = subject.getPrincipals();
        java.util.Iterator prncplsIterator = prncplsSet.iterator();
        while(prncplsIterator.hasNext()){
            Principal principal = (Principal)prncplsIterator.next();
            for(int i = 0; i < roleNames.length; i++){
                if(principal.getName().equals(roleNames[i]))
                    return true;
            }
        }
        return false;
        }catch(org.openejb.OpenEJBException oee){
            return false;
            // FIXME: this interface should throw org.openejb.spi.ServiceExceptions
        }
    }

    /**
    * Attempts to convert an opaque securityIdentity to a concrete target type.
    * This is currently used to obtain an java.security.Princiapl type which
    * must be returned by OpenEJB when a bean invokes EJBContext.getCallerPrincipal().
    * Conversion to a Principal type must be supported.
    *
    * It may also be used by JCX connectors to obtain the JAAS Subject of the caller,
    * support for translation to Subject type is currently optional.
    *
    */
    public Object translateTo(Object securityIdentity, Class type){
        try{
        if(Principal.class.isAssignableFrom(type)){
            Subject subject = getSubject(securityIdentity);
            return subject.getPrincipals().iterator().next();
        }else if(Subject.class.isAssignableFrom(type)){
            return getSubject(securityIdentity);
        }else{
            return null;
            // FIXME: Should throw InvalidArgumentException or someting like that
        }
        }catch(org.openejb.SystemException se){
            return null;
            //FIXME: should throw a service exception
        }
    }
    /*
     * Associates a security identity object with the current thread. Setting 
     * this argument to null, will effectively dissociate the thread with a
     * security identity.  This is used when access enterprise beans through 
     * the global JNDI name space. Its not used when calling invoke on a 
     * RpcContainer object.
    */
    public void setSecurityIdentity(Object securityIdentity){
        threadStorage.set(securityIdentity);
    }
    
    /*
    * Obtains the security identity associated with the current thread.
    * If there is no association, then null is returned. 
    */
    public Object getSecurityIdentity( ){
        Object secId = threadStorage.get();
        try{
        if(secId == null)
            return getSubject(null);
        }catch(org.openejb.OpenEJBException oe){
        }
        return secId;
            
    }
}