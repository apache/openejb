/**
 * Redistribution and use of this software and associated documentation
 * ("Software"), with or without modification, are permitted provided
 * that the following conditions are met:
 *
 * 1. Redistributions of source code must retain copyright
 *    statements and notices.  Redistributions must also contain a
 *    copy of this document.
 *
 * 2. Redistributions in binary form must reproduce the
 *    above copyright notice, this list of conditions and the
 *    following disclaimer in the documentation and/or other
 *    materials provided with the distribution.
 *
 * 3. The name "Exolab" must not be used to endorse or promote
 *    products derived from this Software without prior written
 *    permission of Exoffice Technologies.  For written permission,
 *    please contact info@exolab.org.
 *
 * 4. Products derived from this Software may not be called "Exolab"
 *    nor may "Exolab" appear in their names without prior written
 *    permission of Exoffice Technologies. Exolab is a registered
 *    trademark of Exoffice Technologies.
 *
 * 5. Due credit should be given to the Exolab Project
 *    (http://www.exolab.org/).
 *
 * THIS SOFTWARE IS PROVIDED BY EXOFFICE TECHNOLOGIES AND CONTRIBUTORS
 * ``AS IS'' AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT
 * NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND
 * FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL
 * EXOFFICE TECHNOLOGIES OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * Copyright 1999 (C) Exoffice Technologies Inc. All Rights Reserved.
 *
 * $Id: CastorTransactionScopeHandler.java,v 1.3 2001/12/06 20:58:44 jdaniel Exp $
 */
package org.openejb.alt.containers.castor_cmp11;

import java.lang.reflect.Method;
import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.Hashtable;
import javax.ejb.EnterpriseBean;
import javax.ejb.EntityBean;
import javax.transaction.Status;
import javax.transaction.Transaction;
import javax.transaction.TransactionManager;
import javax.transaction.TransactionRolledbackException;
import org.openejb.ApplicationException;
import org.openejb.Container;
import org.openejb.DeploymentInfo;
import org.openejb.InvalidateReferenceException;
import org.openejb.core.ThreadContext;
import java.util.Hashtable;
import org.exolab.castor.jdo.Database;
import org.exolab.castor.jdo.JDO;
import org.openejb.OpenEJB;

public class CastorTransactionScopeHandler 
extends org.openejb.core.TransactionScopeHandler{
    
    protected Hashtable txReadyPoolMap = null;
    protected JDO jdo_ForLocalTransaction = null;
    protected JDO jdo_ForGlobalTransaction = null;
    
    public CastorTransactionScopeHandler(Container cntr, Hashtable txMethodReadyPool, JDO jdoForLocalTransaction,
      JDO jdoForGlobalTransaction ){
        super(cntr);
        this.txReadyPoolMap = txMethodReadyPool;
        jdo_ForLocalTransaction = jdoForLocalTransaction;
        jdo_ForGlobalTransaction = jdoForGlobalTransaction;
    }
    
   
    public Transaction beforeInvoke(Method method, javax.ejb.EnterpriseBean bean,ThreadContext callContext)
    throws org.openejb.SystemException, org.openejb.ApplicationException{
        Transaction originalTransaction = super.beforeInvoke(method, bean, callContext);
        Database db = null;
        try{
   
        if(OpenEJB.getTransactionManager().getTransaction()== null ) {
            
            /*
            * No current transaciton means that a local transaciton is required which must be executed on 
            * Database object aquired from a JDO object that was not initated with a transaction manager name.
            */
            
            db = jdo_ForLocalTransaction.getDatabase();
            
            /*
            * The fact that there is no transaction following the processing of the super class' beforeInvoke( ) method
            * indicates that the request must execute in a Castor local transaction.  To get that local transacion started
            * the begin() method is invoked. The local transaction will be committed by the afterInoke() method of this class or
            * rolled back by the noTxPolicy( ) of the class, which is delegated to by the handleException of the super class.
            */
            db.begin();
            
            /* 
            * Places a non-transaction managed database object into the unspecified field of the 
            * current transaction context. This will be used later by the getDatabase( ) method of this
            * class to provide the correct database object. Its also used by the CastorTransactionScopeHandler.afterInovoke()
            * method to commit the local transaction and the CastorTransactionScopeHandler.handlException( ) method to rollback the 
            * Castor's local transaction.
            */
            callContext.setUnspecified(db);
        }else{
            /*
            * If there is a transaction, that means that context is transaction-managed so we
            * make the unspecified field of the current ThreadContext null, which will be used by the 
            * getDatabase( ) method of this class to determine that a transaction-managed database object
            * is needed.
            */
            callContext.setUnspecified(null);
        }
        return originalTransaction;
        }catch(javax.transaction.SystemException se){
            throw new org.openejb.SystemException("Transaction Manager failure", se);
        }catch(org.exolab.castor.jdo.DatabaseNotFoundException dnfe){
            throw new org.openejb.SystemException("Castor JDO DatabaseNotFoundException thrown when attempting to begin a local transaciton", dnfe);
        }catch(org.exolab.castor.jdo.PersistenceException pe){
            throw new org.openejb.SystemException("Castor JDO PersistenceException thrown when attempting to begin local transaciton", pe);
        }
    }
    public void afterInvoke(Method method, EnterpriseBean bean, ThreadContext threadContext,Transaction originalTx)
    throws org.openejb.ApplicationException, org.openejb.SystemException{
	boolean commit = true;
      try {
        if(org.openejb.OpenEJB.getTransactionManager().getTransaction()!=null) {
          super.afterInvoke(method, bean, threadContext, originalTx);
        }
        else{
          try{
             Database db = (Database)threadContext.getUnspecified();
                try{
                    ((javax.ejb.EntityBean)bean).ejbStore();
                }catch(Exception re){
			commit = false;
		   }
             if(db!=null) { 
		if ( commit )
                	db.commit();
		else
			db.rollback();
              }  
                if( originalTx!=null){
                    try{
                        getTxMngr( ).resume(originalTx);
                    }catch(javax.transaction.InvalidTransactionException ite){
                        // do nothing if the client's tx has become invalid
                        // log exception
                    }
                }
       }catch(org.exolab.castor.jdo.TransactionAbortedException tae){
                tae.printStackTrace();
                throw new ApplicationException(new java.rmi.RemoteException("Castor JDO threw a JDO TransactionAbortedException while attempting to commit a local transaciton",tae));
            }catch(org.exolab.castor.jdo.TransactionNotInProgressException tnip){
            }
        
        }
        }catch(javax.transaction.SystemException se){
            throw new org.openejb.SystemException("TransactionManager exception",se);
        }
    }
    protected void noTxPolicy(ThreadContext threadContext, EnterpriseBean bean, Throwable throwable, boolean isSystemException)
    throws ApplicationException, InvalidateReferenceException, org.openejb.SystemException{
        
        try{
            if(org.openejb.OpenEJB.getTransactionManager().getTransaction()==null){
                try{
                Database db = (Database)threadContext.getUnspecified();
                db.rollback();
                }catch(org.exolab.castor.jdo.TransactionNotInProgressException tnipe){
                    // do nothing. At this point JDO's tx state is not important to handling the exception.
                }
            }
            super.noTxPolicy(threadContext, bean, throwable, isSystemException);
        }catch(javax.transaction.SystemException se){
            throw new org.openejb.SystemException("TransactionManager exception",se);
        }
            
    }
      
    
    protected void discardBeanInstance(EnterpriseBean bean, ThreadContext threadContext)
    throws org.openejb.SystemException{
        if(bean!=null)
	{
	 txReadyPoolMap.remove(bean);
	 org.openejb.OpenEJB.getApplicationServer().discardCurrentBean();
	}
    }
    protected void afterBeginBMT(Transaction currentTx, ThreadContext threadContext)
    throws org.openejb.SystemException{
        // this method is unlikely to ever be called.
        throw new org.openejb.SystemException("Entity beans can not have Bean Managed Transactions");
    }
}
