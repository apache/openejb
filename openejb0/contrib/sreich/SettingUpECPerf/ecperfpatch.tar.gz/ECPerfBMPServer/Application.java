//
// Application.java
// Project ECPerfBMPServer
//
// Created by reich on Tue Oct 16 2001
//

import com.webobjects.foundation.*;
import com.webobjects.appserver.*;
import com.webobjects.eocontrol.*;
import javax.ejb.*;
import javax.naming.*;

import com.sun.ecperf.mfg.largeorderent.ejb.*;

public class Application extends WOApplication {
    
    public static void main(String argv[]) {
        WOApplication.main(argv, Application.class);
    }

    public Application() {
        super();
        System.out.println("Welcome to " + this.name() + "!");

        test();
    }

    public void test() {
        try{
            LargeOrderEntHome largeOrderEnHhome = (LargeOrderEntHome)javax.rmi.PortableRemoteObject.narrow(new InitialContext().lookup("LargeOrderEnt"), LargeOrderEntHome.class);
            java.util.Enumeration c = largeOrderEnHhome.findAll();
        }catch(java.rmi.RemoteException e) {
            System.err.println("caught exception "+e);
        }catch(Exception e) {
            System.err.println("The container must throw an exception derived from javax.rmi.RemoteException, but threw "+e);
        }
        
        System.err.println("finished");
    }        

    public void verify() {
        String[] allBeans= new String[]{
            "AssemblyEnt",
            "BomEnt",
            "BuyerSes",
            "CartSes",
            "ComponentEnt",
            "CorpAuditSes",
            "CustomerEnt",
            "DiscountEnt",
            "InventoryEnt",
            "ItemEnt",
            "LargeOrderEnt",
            "LargeOrderSes",
            "MfgAuditSes",
            "OrderAuditSes",
            "OrderCustomerEnt",
            "OrderCustomerSes",
            "OrderEnt",
            "OrderLineEnt",
            "OrderSes",
            "POEnt",
            "POLineEnt",
            "PartEnt",
            "ReceiveSes",
            "ReceiverSes",
            "RuleEnt",
            "SComponentEnt",
            "SequenceEnt",
            "SequenceSes",
            "SupplierAuditSes",
            "SupplierCompEnt",
            "SupplierEnt",
            "WorkOrderEnt",
            "WorkOrderSes",
        };

        for(int i=0; i<allBeans.length; ++i) {
            try{
                EJBHome h = (EJBHome)javax.rmi.PortableRemoteObject.narrow(new InitialContext().lookup(allBeans[i]), EJBHome.class);
                EJBMetaData m = h.getEJBMetaData();
                if(!h.equals(m.getEJBHome())) {
                    System.err.println("Aua");
                }
                if(m.isStatelessSession() && !m.isSession()) {
                    System.err.println("Aua");
                }
                String message="Home interface class="+m.getHomeInterfaceClass().getName()+
                    ", remote interface class="+m.getRemoteInterfaceClass().getName()+
                    ", isSession="+m.isSession()+
                    ", stateless="+m.isStatelessSession();
                if(!m.isSession()) {
                    message+=", PK class="+m.getPrimaryKeyClass().getName();
                }
                //                System.out.println(message);
            }
            catch(Exception e) {
                e.printStackTrace();
            }
        }
    }
    
}
